import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import './utils/auth'; // Initialize authentication
import UnifiedSwarmChat from './pages/UnifiedSwarmChat';
import ModernDashboard from './components/ModernDashboard';
import ModernDashboardDemo from './components/ModernDashboardDemo';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <div className="header-content">
            <div className="header-title">
              <span className="logo-icon">🚀</span>
              <h1>Strands AI Agent System</h1>
            </div>
            <nav className="nav-menu">
              <NavLink to="/" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                <span className="nav-icon">🎯</span>
                <span className="nav-text">Dashboard</span>
              </NavLink>
              <NavLink to="/swarm" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                <span className="nav-icon">✨</span>
                <span className="nav-text">Swarm AI</span>
              </NavLink>
              <NavLink to="/demo" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
                <span className="nav-icon">🎪</span>
                <span className="nav-text">Demo</span>
              </NavLink>
            </nav>
          </div>
        </header>
        <main>
          <Routes>
            {/* Main Dashboard */}
            <Route path="/" element={<ModernDashboard />} />
            
            {/* Unified Swarm Chat - Replaces all old chat interfaces */}
            <Route path="/swarm" element={<UnifiedSwarmChat />} />
            
            {/* Demo Dashboard for testing */}
            <Route path="/demo" element={<ModernDashboardDemo />} />
            
            {/* Redirect old routes to new unified interface */}
            <Route path="/chat" element={<UnifiedSwarmChat />} />
            <Route path="/execute" element={<UnifiedSwarmChat />} />
            <Route path="/swarm-executor" element={<UnifiedSwarmChat />} />
            <Route path="/swarm-chat" element={<UnifiedSwarmChat />} />
            <Route path="/swarm-old" element={<UnifiedSwarmChat />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;