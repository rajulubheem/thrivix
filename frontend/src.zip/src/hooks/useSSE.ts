import { useEffect, useState, useCallback, useRef } from 'react';
import { SwarmEvent } from '../types/swarm';

interface UseSSEOptions {
  onEvent?: (event: SwarmEvent) => void;
  onError?: (error: Event) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

export function useSSE(executionId: string | null, options: UseSSEOptions = {}) {
  const [isConnected, setIsConnected] = useState(false);
  const [events, setEvents] = useState<SwarmEvent[]>([]);
  const [executionComplete, setExecutionComplete] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);
  const processedEvents = useRef(new Set<string>());
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);

  const { onEvent, onError, onOpen, onClose } = options;

  // Store callback refs to avoid reconnections when callbacks change
  const callbackRefs = useRef({ onEvent, onError, onOpen, onClose });
  callbackRefs.current = { onEvent, onError, onOpen, onClose };

  // Handle SSE event data
  const handleSSEEvent = useCallback((eventData: string) => {
    try {
      // console.log('📥 SSE Event received:', eventData);
      const data = JSON.parse(eventData);

      // Handle connection established separately (don't add to events)
      if (data.type === 'connection_established') {
        console.log('✅ SSE Connection established');
        return;
      }

      // Handle status check for already completed executions
      if (data.type === 'status_check') {
        console.log('📊 Execution status:', data.status);
        if (data.status === 'completed' || data.status === 'failed' || data.status === 'stopped') {
          // Don't try to reconnect to completed executions
          reconnectAttemptsRef.current = 999; // Prevent reconnection
        }
        return;
      }

      // Build the swarm event based on type
      let swarmEvent: SwarmEvent;

      if (data.type === 'swarm_event' && data.event) {
        // For swarm_event, use the nested event data
        swarmEvent = {
          type: data.event.type,
          timestamp: data.event.timestamp || data.timestamp,
          agent: data.event.agent,
          data: data.event.data
        };
      } else if (data.type === 'execution_completed') {
        // For execution_completed, structure the data properly
        swarmEvent = {
          type: data.type,
          timestamp: data.timestamp,
          agent: undefined,
          data: data.result ? { result: data.result } : {}
        };
      } else if (data.type === 'execution_failed') {
        // Handle execution failure
        swarmEvent = {
          type: data.type,
          timestamp: data.timestamp,
          agent: undefined,
          data: { error: data.error }
        };
      } else if (data.type === 'execution_started' || data.type === 'execution_stopped') {
        // Handle other execution events
        swarmEvent = {
          type: data.type,
          timestamp: data.timestamp,
          agent: undefined,
          data: {}
        };
      } else {
        // For any other events
        swarmEvent = {
          type: data.type || 'unknown',
          timestamp: data.timestamp || new Date().toISOString(),
          agent: data.agent,
          data: data.data || {}
        };
      }

      // Create unique key for deduplication
      const eventKey = `${swarmEvent.type}-${swarmEvent.timestamp}-${swarmEvent.agent || 'system'}`;

      if (!processedEvents.current.has(eventKey)) {
        processedEvents.current.add(eventKey);
        console.log('✅ Processing event:', swarmEvent.type);

        // Now swarmEvent is guaranteed to be non-null
        setEvents(prev => [...prev, swarmEvent]);
        callbackRefs.current.onEvent?.(swarmEvent);

        // Track completion state
        if (swarmEvent.type === 'execution_completed' ||
            swarmEvent.type === 'execution_failed' ||
            swarmEvent.type === 'execution_stopped') {
          setExecutionComplete(true);
        }
      } else {
        console.log('⚠️ Duplicate event ignored:', eventKey);
      }
    } catch (error) {
      console.error('❌ Failed to parse SSE event:', error, 'Data:', eventData);
    }
  }, []);

  // Connect to SSE endpoint
  const connect = useCallback(() => {
    if (!executionId || eventSourceRef.current || executionComplete) {
      if (executionComplete) {
        console.log('⚠️ Not connecting - execution already complete');
      }
      return;
    }

    console.log('🔌 Connecting to SSE for execution:', executionId);

    const baseUrl = process.env.REACT_APP_API_URL || 'http://localhost:8000';
    // Use the no-auth endpoint
    const url = `${baseUrl}/api/v1/sse_noauth/events/${executionId}`;

    try {
      const eventSource = new EventSource(url);
      eventSourceRef.current = eventSource;

      // Connection opened
      eventSource.onopen = (event) => {
        console.log('✅ SSE connection opened');
        setIsConnected(true);
        reconnectAttemptsRef.current = 0;
        callbackRefs.current.onOpen?.();
      };

      // Handle messages
      eventSource.onmessage = (event) => {
        // console.log('📨 SSE message received:', event.data);
        handleSSEEvent(event.data);
      };

      // Handle specific event types if needed
      eventSource.addEventListener('ping', (event) => {
        console.log('🏓 SSE ping received');
      });

      // Handle errors
      eventSource.onerror = (error) => {
        console.error('❌ SSE error:', error);
        setIsConnected(false);

        // Check if this was after a completion event
        const lastEvent = events[events.length - 1];
        if (lastEvent && (lastEvent.type === 'execution_completed' ||
                         lastEvent.type === 'execution_failed' ||
                         lastEvent.type === 'execution_stopped')) {
          console.log('✅ SSE closed after execution completed - this is normal');
          eventSource.close();
          eventSourceRef.current = null;
          return; // Don't reconnect after completion
        }

        // EventSource will auto-reconnect, but we can add our own logic
        if (eventSource.readyState === EventSource.CLOSED) {
          console.log('🔄 SSE connection closed, attempting reconnect...');

          // Clear the current connection
          eventSource.close();
          eventSourceRef.current = null;

          // Exponential backoff for reconnection
          const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
          reconnectAttemptsRef.current++;

          if (reconnectAttemptsRef.current < 10) {
            console.log(`⏱️ Reconnecting in ${delay}ms (attempt ${reconnectAttemptsRef.current})`);
            reconnectTimeoutRef.current = setTimeout(() => {
              connect();
            }, delay);
          } else {
            console.error('❌ Max reconnection attempts reached');
            callbackRefs.current.onError?.(error);
          }
        }

        callbackRefs.current.onError?.(error);
      };

    } catch (error) {
      console.error('❌ Failed to create EventSource:', error);
      setIsConnected(false);
      callbackRefs.current.onError?.(error as Event);
    }
  }, [executionId, handleSSEEvent]);

  // Disconnect from SSE
  const disconnect = useCallback(() => {
    console.log('🔌 Disconnecting SSE');

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }

    setIsConnected(false);
    reconnectAttemptsRef.current = 0;
    callbackRefs.current.onClose?.();
  }, []);

  // Clear events
  const clearEvents = useCallback(() => {
    setEvents([]);
    processedEvents.current.clear();
    setExecutionComplete(false);
  }, []);

  // Auto-connect when executionId changes
  useEffect(() => {
    if (executionId) {
      console.log(`🔗 SSE: New execution ID received: ${executionId}`);
      // Clear previous events when starting new execution
      clearEvents();
      connect();
    } else {
      console.log('🔗 SSE: No execution ID, disconnecting');
      disconnect();
    }

    // Cleanup on unmount or executionId change
    return () => {
      disconnect();
    };
  }, [executionId]); // Only depend on executionId, not connect/disconnect to avoid loops

  return {
    isConnected,
    events,
    connect,
    disconnect,
    clearEvents
  };
}