import { useEffect, useState, useCallback, useRef } from 'react';
import { SwarmEvent } from '../types/swarm';

interface UseSSEOptions {
  onEvent?: (event: SwarmEvent) => void;
  onError?: (error: Event) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

export function useSSE(executionId: string | null, options: UseSSEOptions = {}) {
  const [isConnected, setIsConnected] = useState(false);
  const [events, setEvents] = useState<SwarmEvent[]>([]);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const processedEvents = useRef(new Set<string>());
  
  const { onEvent, onError, onOpen, onClose } = options;

  // Store callback refs to avoid reconnections when callbacks change
  const callbackRefs = useRef({ onEvent, onError, onOpen, onClose });
  callbackRefs.current = { onEvent, onError, onOpen, onClose };

  // Handle any SSE event data
  const handleSSEEvent = useCallback((eventData: string) => {
    try {
      console.log('🔄 Processing SSE data:', eventData);
      const data = JSON.parse(eventData);
      console.log('📊 Parsed data:', data);
      
      // Handle different event types
      let swarmEvent: SwarmEvent;
      
      if (data.type === 'swarm_event' && data.event) {
        // For swarm_event, use the nested event data
        swarmEvent = {
          type: data.event.type,
          timestamp: data.event.timestamp,
          agent: data.event.agent,
          data: data.event.data
        };
      } else if (data.type === 'execution_completed' && data.result) {
        // For execution_completed, structure the data properly
        swarmEvent = {
          type: data.type,
          timestamp: data.timestamp,
          agent: undefined,
          data: { result: data.result }
        };
      } else {
        // For other events like execution_started
        swarmEvent = {
          type: data.type,
          timestamp: data.timestamp,
          agent: data.event?.agent,
          data: data.event?.data || {}
        };
      }
      
      console.log('✅ Final SwarmEvent:', swarmEvent);
      
      // Create unique key for deduplication
      const eventKey = `${swarmEvent.type}-${swarmEvent.timestamp}-${swarmEvent.agent}`;
      if (!processedEvents.current.has(eventKey)) {
        processedEvents.current.add(eventKey);
        setEvents(prev => [...prev, swarmEvent]);
        callbackRefs.current.onEvent?.(swarmEvent);
      }
    } catch (error) {
      console.error('❌ Failed to parse SSE event:', error, eventData);
    }
  }, []);

  // Manual SSE implementation using fetch
  const startPolling = useCallback(async () => {
    if (!executionId) return;
    
    console.log('🔄 Starting MANUAL SSE for:', executionId);
    setIsConnected(true);
    callbackRefs.current.onOpen?.();
    
    const fetchEvents = async () => {
      try {
        console.log('📡 Fetching SSE events...');
        const response = await fetch(`http://localhost:8000/api/v1/sse/events/${executionId}`, {
          headers: {
            'Accept': 'text/event-stream',
            'Cache-Control': 'no-cache'
          }
        });
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const text = await response.text();
        console.log('📥 Received SSE data (first 300 chars):', text.substring(0, 300));
        
        if (text.trim()) {
          // Parse SSE format manually
          const lines = text.split('\n');
          let currentEvent: { event?: string; data?: string } = {};
          
          for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('event:')) {
              currentEvent.event = trimmedLine.substring(6).trim();
            } else if (trimmedLine.startsWith('data:')) {
              currentEvent.data = trimmedLine.substring(5).trim();
              
              // Process complete event
              if (currentEvent.event === 'execution_event' && currentEvent.data) {
                console.log('🎯 Processing manual SSE event:', currentEvent.data);
                handleSSEEvent(currentEvent.data);
              }
              currentEvent = {}; // Reset for next event
            }
          }
        }
        
      } catch (error) {
        console.error('❌ Manual SSE fetch error:', error);
        callbackRefs.current.onError?.(error as any);
      }
    };
    
    // Do initial fetch
    await fetchEvents();
    
    // Poll every 1 second
    pollingRef.current = setInterval(fetchEvents, 1000);
  }, [executionId, handleSSEEvent]);

  const disconnect = useCallback(() => {
    console.log('🔌 Disconnecting manual SSE');
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
    setIsConnected(false);
    callbackRefs.current.onClose?.();
  }, []);

  const clearEvents = useCallback(() => {
    setEvents([]);
    processedEvents.current.clear();
  }, []);

  useEffect(() => {
    if (executionId && !pollingRef.current) {
      startPolling();
    } else if (!executionId) {
      disconnect();
    }

    return () => {
      disconnect();
    };
  }, [executionId, startPolling, disconnect]);

  return {
    isConnected,
    events,
    connect: startPolling,
    disconnect,
    clearEvents
  };
}