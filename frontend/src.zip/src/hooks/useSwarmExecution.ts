// useSwarmExecution.ts - Fixed version with proper metrics calculation
import { useState, useCallback, useEffect } from 'react';
import { SwarmExecutionRequest, SwarmExecutionResult, SwarmEvent, ExecutionMetrics } from '../types/swarm';
import { apiService } from '../services/api';
import { useSSE } from './useSSE';

export function useSwarmExecution() {
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionId, setExecutionId] = useState<string | null>(null);
  const [result, setResult] = useState<SwarmExecutionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [metrics, setMetrics] = useState<ExecutionMetrics | null>(null);

  const { isConnected, events, clearEvents, disconnect } = useSSE(executionId, {
    onEvent: (event: SwarmEvent) => {
      // Handle execution completion
      if (event.type === 'execution_completed') {
        setIsExecuting(false);
        if (event.data?.result) {
          setResult(event.data.result);

          // Update metrics from result
          if (event.data.result) {
            setMetrics(prev => ({
              totalAgents: event.data.result.agent_sequence?.length || prev?.totalAgents || 0,
              handoffs: event.data.result.handoffs || prev?.handoffs || 0,
              toolUses: prev?.toolUses || 0,
              events: events.length + 1,
              tokensUsed: event.data.result.tokens_used || 0,
              executionTime: event.data.result.execution_time || 0
            }));
          }
        }
        // Disconnect SSE after completion to avoid errors
        setTimeout(() => {
          disconnect();
          setExecutionId(null);
        }, 100);
      } else if (event.type === 'execution_failed') {
        setIsExecuting(false);
        setError(event.data?.error || 'Execution failed');
        // Disconnect SSE after failure
        setTimeout(() => {
          disconnect();
          setExecutionId(null);
        }, 100);
      }
    },
    onError: (error) => {
      // Only log error if we're still executing and it's not a normal closure
      if (isExecuting && error instanceof Event && error.type === 'error') {
        const eventSource = error.target as EventSource;
        // Check if this is a normal closure after completion
        if (eventSource.readyState === EventSource.CLOSED) {
          const lastEvent = events[events.length - 1];
          if (lastEvent && lastEvent.type === 'execution_completed') {
            console.log('✅ SSE connection closed normally after completion');
            return;
          }
        }
        console.error('SSE Error during execution:', error);
        setError('Connection error occurred');
      }
    }
  });

  // Calculate metrics whenever events change
  useEffect(() => {
    if (events.length > 0) {
      calculateMetrics(events);
    }
  }, [events]);

  const calculateMetrics = useCallback((currentEvents: SwarmEvent[]) => {
    const agentSet = new Set<string>();
    let handoffs = 0;
    let toolUses = 0;
    let tokensUsed = 0;

    currentEvents.forEach(event => {
      // Track unique agents
      if (event.agent) {
        agentSet.add(event.agent);
      }

      // Count event types
      switch (event.type) {
        case 'handoff':
          handoffs++;
          break;
        case 'tool_use':
          toolUses++;
          break;
        case 'agent_completed':
          if (event.data?.tokens) {
            tokensUsed += event.data.tokens;
          }
          break;
      }
    });

    setMetrics(prev => ({
      totalAgents: agentSet.size || prev?.totalAgents || 0,
      handoffs: handoffs || prev?.handoffs || 0,
      toolUses: toolUses || prev?.toolUses || 0,
      events: currentEvents.length,
      tokensUsed: tokensUsed || prev?.tokensUsed || 0,
      executionTime: prev?.executionTime || 0
    }));
  }, []);

  const execute = useCallback(async (request: SwarmExecutionRequest) => {
    try {
      // Reset state
      setIsExecuting(true);
      setError(null);
      setResult(null);
      setMetrics(null);
      clearEvents();

      console.log('🚀 Starting swarm execution with request:', request);

      // Try streaming execution, fallback to regular if fails
      try {
        const response = await apiService.executeSwarmStream(request);
        console.log('📥 Received execution ID:', response.execution_id);
        setExecutionId(response.execution_id);
      } catch (streamError) {
        console.warn('⚠️ SSE streaming failed, using regular execution:', streamError);
        // Fallback to regular execution endpoint
        const result = await apiService.executeSwarm(request);
        console.log('✅ Regular execution completed:', result);
        setResult(result);
        setIsExecuting(false);
        // Simulate completion event
        if (result) {
          setMetrics({
            totalAgents: result.agent_sequence?.length || 0,
            handoffs: result.handoffs || 0,
            toolUses: 0,
            events: 1,
            tokensUsed: result.tokens_used || 0,
            executionTime: result.execution_time || 0
          });
        }
      }

    } catch (err) {
      setIsExecuting(false);
      setError(err instanceof Error ? err.message : 'Failed to start execution');
      console.error('❌ Execution failed:', err);
    }
  }, [clearEvents]);

  const stop = useCallback(async (execId: string) => {
    try {
      await apiService.stopExecution(execId);
      setIsExecuting(false);
      console.log('⏹️ Execution stopped');
    } catch (err) {
      console.error('❌ Failed to stop execution:', err);
    }
  }, []);

  const reset = useCallback(() => {
    setIsExecuting(false);
    setExecutionId(null);
    setResult(null);
    setError(null);
    setMetrics(null);
    clearEvents();
  }, [clearEvents]);

  return {
    execute,
    stop,
    reset,
    isExecuting,
    executionId,
    events,
    result,
    metrics,
    error,
    isConnected
  };
}