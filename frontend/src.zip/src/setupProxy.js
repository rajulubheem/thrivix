const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:8000',
      changeOrigin: true,
      ws: true,
      onProxyReq: (proxyReq, req, res) => {
        // Add authentication header if not present
        if (!proxyReq.getHeader('Authorization')) {
          proxyReq.setHeader('Authorization', 'Bearer demo-token');
        }
      }
    })
  );
};