export interface Agent {
  name: string;
  system_prompt: string;
  tools: string[];
  model_id?: string;
  description?: string;
  icon?: string;
}

export interface SwarmExecutionRequest {
  task: string;
  agents: Agent[];
  max_handoffs?: number;
  max_iterations?: number;
  execution_timeout?: number;
  node_timeout?: number;
  execution_id?: string;
  background?: boolean;
}

export interface SwarmExecutionResult {
  execution_id: string;
  status: 'completed' | 'failed' | 'stopped';
  result?: string;
  error?: string;
  execution_time?: number;
  handoffs: number;
  tokens_used: number;
  agent_sequence: string[];
  artifacts: Artifact[];
}

export interface SwarmEvent {
  type: 'agent_started' | 'agent_completed' | 'tool_use' | 'text_generation' | 
      'handoff' | 'error' | 'execution_started' | 'execution_completed' | 
      'execution_failed' | 'execution_stopped' | 'system_message';
  timestamp: string;
  agent?: string;
  data?: any;
}

export interface Artifact {
  id: string;
  type: 'code' | 'html' | 'document' | 'data' | 'image' | 'test_result';
  title: string;
  content: string;
  language?: string;
  filename?: string;
  agentId?: string;
  timestamp?: Date;
  size?: number;
  metadata?: {
    language?: string;
    agent?: string;
    lines?: number;
    functions?: number;
    [key: string]: any;
  };
}

export interface ExecutionMetrics {
  totalAgents: number;
  handoffs: number;
  toolUses: number;
  events: number;
  tokensUsed?: number;
  executionTime?: number;
}

export interface AgentTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  system_prompt: string;
  tools: string[];
  category: 'research' | 'development' | 'analysis' | 'creative' | 'review';
}