import React, { useEffect, useState } from 'react';
import './SimpleAgentTimeline.css';

interface AgentEvent {
  agent: string;
  action: string;
  status: 'running' | 'complete' | 'failed';
  timestamp: Date;
  duration?: number;
}

interface SimpleAgentTimelineProps {
  events: AgentEvent[];
  currentAgent?: string;
}

const SimpleAgentTimeline: React.FC<SimpleAgentTimelineProps> = ({ events, currentAgent }) => {
  const [displayedEvents, setDisplayedEvents] = useState<AgentEvent[]>([]);
  const [animatedAgents, setAnimatedAgents] = useState<Set<string>>(new Set());
  
  // Smooth event streaming with delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setDisplayedEvents(events);
    }, 100);
    return () => clearTimeout(timer);
  }, [events]);
  
  // Track which agents should animate
  useEffect(() => {
    if (currentAgent) {
      setAnimatedAgents(prev => new Set(prev).add(currentAgent));
    }
  }, [currentAgent]);
  
  // Group events by agent
  const agentGroups = displayedEvents.reduce((acc, event) => {
    if (!acc[event.agent]) acc[event.agent] = [];
    acc[event.agent].push(event);
    return acc;
  }, {} as Record<string, AgentEvent[]>);
  
  const getAgentEmoji = (agent: string) => {
    const emojis: Record<string, string> = {
      researcher: '🔬',
      architect: '🏗️',
      developer: '💻',
      reviewer: '✅',
      tester: '🧪',
      data_scientist: '📊',
      devops: '🚀'
    };
    return emojis[agent.toLowerCase()] || '🤖';
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return '#3b82f6';
      case 'complete': return '#10b981';
      case 'failed': return '#ef4444';
      default: return '#6b7280';
    }
  };
  
  return (
    <div className="simple-timeline">
      <h3>Agent Activity</h3>
      <div className="timeline-lanes">
        {Object.entries(agentGroups).map(([agent, agentEvents], laneIdx) => (
          <div 
            key={agent} 
            className={`agent-lane ${agent === currentAgent ? 'active' : ''}`}
            style={{ animationDelay: `${laneIdx * 0.1}s` }}
          >
            <div className="agent-header">
              <span className="agent-emoji">{getAgentEmoji(agent)}</span>
              <span className="agent-name">{agent}</span>
              {agent === currentAgent && <span className="status-dot running"></span>}
            </div>
            <div className="agent-events">
              {agentEvents.map((event, idx) => (
                <div 
                  key={idx} 
                  className={`event-item ${event.status}`}
                  style={{ 
                    borderLeftColor: getStatusColor(event.status),
                    animationDelay: `${(laneIdx * 0.1) + (idx * 0.05)}s`
                  }}
                >
                  <div className="event-content">
                    <span className="event-action">{event.action}</span>
                    <span className="event-time">
                      {event.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
        {Object.keys(agentGroups).length === 0 && (
          <div style={{ 
            textAlign: 'center', 
            padding: '3rem', 
            color: '#94a3b8',
            fontSize: '0.875rem'
          }}>
            Waiting for agents to start...
          </div>
        )}
      </div>
    </div>
  );
};

export default SimpleAgentTimeline;