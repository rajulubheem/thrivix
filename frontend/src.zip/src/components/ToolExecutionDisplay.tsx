import React from 'react';
import { 
  Wrench, 
  FileText, 
  Search, 
  Code, 
  Calculator, 
  Globe, 
  Database,
  Terminal,
  Brain,
  GitBranch,
  Clock,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import './ToolExecutionDisplay.css';

interface ToolExecution {
  agent: string;
  tool: string;
  timestamp: string;
  status?: 'running' | 'completed' | 'error';
  result?: any;
}

interface ToolExecutionDisplayProps {
  executions: ToolExecution[];
  isLive?: boolean;
}

const ToolExecutionDisplay: React.FC<ToolExecutionDisplayProps> = ({ 
  executions, 
  isLive = false 
}) => {
  // Map tool names to icons
  const getToolIcon = (toolName: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      'file_read': <FileText className="tool-icon" />,
      'file_write': <FileText className="tool-icon" />,
      'editor': <Code className="tool-icon" />,
      'tavily_search': <Search className="tool-icon" />,
      'http_request': <Globe className="tool-icon" />,
      'calculator': <Calculator className="tool-icon" />,
      'python_repl': <Terminal className="tool-icon" />,
      'shell': <Terminal className="tool-icon" />,
      'use_aws': <Database className="tool-icon" />,
      'think': <Brain className="tool-icon" />,
      'workflow': <GitBranch className="tool-icon" />,
      'current_time': <Clock className="tool-icon" />,
    };
    
    return iconMap[toolName] || <Wrench className="tool-icon" />;
  };

  // Get status icon
  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="status-icon completed" />;
      case 'error':
        return <AlertCircle className="status-icon error" />;
      case 'running':
        return <div className="status-icon running">⚡</div>;
      default:
        return null;
    }
  };

  // Get tool description
  const getToolDescription = (toolName: string): string => {
    const descriptions: { [key: string]: string } = {
      'file_read': 'Reading file contents',
      'file_write': 'Writing to file',
      'editor': 'Editing file',
      'tavily_search': 'Searching the web',
      'tavily_extract': 'Extracting web content',
      'http_request': 'Making HTTP request',
      'calculator': 'Performing calculation',
      'python_repl': 'Executing Python code',
      'shell': 'Running shell command',
      'use_aws': 'Using AWS service',
      'think': 'Reasoning and analysis',
      'workflow': 'Managing workflow',
      'swarm': 'Coordinating agents',
      'diagram': 'Creating diagram',
      'current_time': 'Getting current time',
      'sleep': 'Waiting',
      'handoff_to_user': 'Requesting user input',
    };
    
    return descriptions[toolName] || `Using ${toolName}`;
  };

  if (executions.length === 0) {
    return (
      <div className="tool-execution-display empty">
        <Wrench className="empty-icon" />
        <p>No tools executed yet</p>
      </div>
    );
  }

  return (
    <div className="tool-execution-display">
      <div className="tool-header">
        <h3>
          <Wrench className="header-icon" />
          Tool Executions
          {isLive && <span className="live-badge">LIVE</span>}
        </h3>
      </div>
      
      <div className="tool-timeline">
        {executions.map((execution, index) => (
          <div 
            key={index} 
            className={`tool-execution-item ${execution.status || ''}`}
          >
            <div className="tool-icon-wrapper">
              {getToolIcon(execution.tool)}
            </div>
            
            <div className="tool-details">
              <div className="tool-header-row">
                <span className="agent-name">{execution.agent}</span>
                {getStatusIcon(execution.status)}
              </div>
              
              <div className="tool-name">
                {getToolDescription(execution.tool)}
              </div>
              
              {execution.result && (
                <div className="tool-result">
                  <pre>{JSON.stringify(execution.result, null, 2)}</pre>
                </div>
              )}
              
              <div className="tool-timestamp">
                {new Date(execution.timestamp).toLocaleTimeString()}
              </div>
            </div>
            
            {index < executions.length - 1 && (
              <div className="timeline-connector" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolExecutionDisplay;