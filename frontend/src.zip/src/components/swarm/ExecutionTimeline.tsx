// ExecutionTimeline.tsx - Fixed TypeScript version with real-time streaming
import React, { useMemo, useEffect, useRef } from 'react';
import { SwarmEvent } from '../../types/swarm';
import './ExecutionTimeline.css';

interface ExecutionTimelineProps {
  events: SwarmEvent[];
  isExecuting: boolean;
}

interface ProcessedEvent {
  type: string;
  agent?: string;
  timestamp: string;
  content: any;
  icon: string;
}

interface TextAccumulation {
  agent: string;
  text: string;
  timestamp: string;
}

const ExecutionTimeline: React.FC<ExecutionTimelineProps> = ({ events, isExecuting }) => {
  const timelineEndRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom when new events arrive
  useEffect(() => {
    if (isExecuting && timelineEndRef.current) {
      timelineEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [events, isExecuting]);
  
  // Process and group events for better display with real-time streaming
  const processedEvents = useMemo(() => {
    const processed: ProcessedEvent[] = [];
    const agentTextMap = new Map<string, { text: string, timestamp: string, index: number }>();

    events.forEach((event, index) => {
      // Handle text generation with real-time updates
      if (event.type === 'text_generation') {
        const agent = event.agent || 'system';
        const currentText = event.data?.accumulated || event.data?.text || '';
        
        // Check if we already have text from this agent
        const existingEntry = agentTextMap.get(agent);
        
        if (existingEntry) {
          // Update the existing entry with new accumulated text
          processed[existingEntry.index] = {
            type: 'text_generation',
            agent: agent,
            timestamp: event.timestamp,
            content: currentText,
            icon: '💭'
          };
          existingEntry.text = currentText;
          existingEntry.timestamp = event.timestamp;
        } else {
          // Create new entry for this agent's text
          const newIndex = processed.length;
          processed.push({
            type: 'text_generation',
            agent: agent,
            timestamp: event.timestamp,
            content: currentText,
            icon: '💭'
          });
          agentTextMap.set(agent, { text: currentText, timestamp: event.timestamp, index: newIndex });
        }
      } else {
        // Process other event types
        let icon = '⚪';
        let content: any = event.data || {};

        switch (event.type) {
          case 'agent_started':
            icon = '🔄';
            content = `Agent started (iteration ${event.data?.iteration ?? 0})`;
            break;
          case 'agent_completed':
            icon = '✅';
            content = `Completed with ${event.data?.tokens || 0} tokens`;
            break;
          case 'tool_use':
            icon = '🔧';
            break;
          case 'handoff':
            icon = '↗️';
            content = `Handing off from ${event.data?.from} to ${event.data?.to}`;
            break;
          case 'error':
            icon = '❌';
            break;
          case 'execution_started':
            icon = '🚀';
            content = 'Execution started';
            break;
          case 'execution_completed':
            icon = '🎉';
            content = 'Execution completed successfully';
            break;
          case 'execution_failed':
            icon = '💥';
            content = `Execution failed: ${event.data?.error}`;
            break;
          default:
            break;
        }

        processed.push({
          type: event.type,
          agent: event.agent,
          timestamp: event.timestamp,
          content,
          icon
        });
      }
    });

    return processed;
  }, [events]);

  const getAgentColor = (agentName?: string): string => {
    if (!agentName) return '#6b7280';
    
    const colors: Record<string, string> = {
      researcher: '#3b82f6',
      architect: '#8b5cf6',
      developer: '#10b981',
      tester: '#f59e0b',
      documenter: '#6366f1',
      reviewer: '#ec4899'
    };
    return colors[agentName.toLowerCase()] || '#6b7280';
  };

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="execution-timeline">
      <div className="timeline-header">
        <h3>Execution Timeline</h3>
        {isExecuting && (
          <span className="executing-badge">
            <span className="spinner"></span>
            Executing
          </span>
        )}
      </div>
      
      <div className="timeline-container">
        <div className="timeline-line"></div>
        
        <div className="timeline-events">
          {processedEvents.map((event, index) => (
            <div key={index} className="timeline-event">
              <div className="event-dot">
                <span className="event-icon">{event.icon}</span>
              </div>
              
              <div className="event-content">
                <div className="event-header">
                  {event.agent && (
                    <span 
                      className="agent-badge"
                      style={{ backgroundColor: getAgentColor(event.agent) }}
                    >
                      {event.agent}
                    </span>
                  )}
                  <span className="event-timestamp">
                    {formatTimestamp(event.timestamp)}
                  </span>
                </div>
                
                <div className="event-data">
                  {event.type === 'text_generation' && (
                    <div className="text-content">
                      <p>
                        {event.content}
                        {isExecuting && index === processedEvents.length - 1 && (
                          <span className="typing-cursor">▊</span>
                        )}
                      </p>
                    </div>
                  )}
                  
                  {event.type === 'tool_use' && (
                    <div className="tool-use">
                      <p><strong>Tool:</strong> {event.content.tool}</p>
                      {event.content.arguments && (
                        <pre className="tool-input">
                          {JSON.stringify(event.content.arguments, null, 2)}
                        </pre>
                      )}
                    </div>
                  )}
                  
                  {event.type === 'handoff' && (
                    <p>{event.content}</p>
                  )}
                  
                  {(event.type === 'agent_started' || 
                    event.type === 'agent_completed' ||
                    event.type === 'execution_started' || 
                    event.type === 'execution_completed' || 
                    event.type === 'execution_failed') && (
                    <p>{typeof event.content === 'string' ? event.content : JSON.stringify(event.content)}</p>
                  )}
                  
                  {event.type === 'error' && (
                    <p className="error-message">{event.content.error || 'An error occurred'}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {isExecuting && (
            <div className="timeline-event">
              <div className="event-dot processing">
                <span className="spinner small"></span>
              </div>
              <div className="event-content">
                <p className="processing-text">Processing...</p>
              </div>
            </div>
          )}
        </div>
        <div ref={timelineEndRef} />
      </div>
    </div>
  );
};

export default ExecutionTimeline;