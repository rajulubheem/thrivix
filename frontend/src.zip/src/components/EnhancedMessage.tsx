// EnhancedMessage.tsx - Updated to use unified Artifact interface

import React, { useState, useMemo } from 'react';
import { Copy, Check, Code, FileText, Eye, Download, ExternalLink } from 'lucide-react';
import { Artifact } from '../types/artifacts'; // Import unified Artifact type

interface CodeBlock {
  language: string;
  code: string;
  filename?: string;
}

interface EnhancedMessageProps {
  content: string;
  agent?: string;
  status?: 'thinking' | 'streaming' | 'complete' | 'error';
  timestamp: Date;
  onArtifactCreate?: (artifact: Artifact) => void; // Updated to use Artifact
  artifacts?: Artifact[]; // Updated to use Artifact[]
}

const EnhancedMessage: React.FC<EnhancedMessageProps> = ({
                                                           content,
                                                           agent,
                                                           status,
                                                           timestamp,
                                                           onArtifactCreate,
                                                           artifacts = []
                                                         }) => {
  const [copiedBlocks, setCopiedBlocks] = useState<Set<number>>(new Set());

  // Parse content to extract code blocks, files, and structured content
  const parsedContent = useMemo(() => {
    if (!content) return { parts: [] };

    const parts: Array<{
      type: 'text' | 'code' | 'file' | 'section' | 'list' | 'heading';
      content: string;
      language?: string;
      filename?: string;
      level?: number;
    }> = [];

    // Split content by code blocks first
    const codeBlockRegex = /```(\w+)?\n?([\s\S]*?)```/g;
    const fileBlockRegex = /#\s*filename:\s*([^\n]+)\n([\s\S]*?)(?=\n#|\n```|$)/g;
    const headingRegex = /^(#{1,6})\s+(.+)$/gm;
    const listRegex = /^[\s]*[-*+]\s+(.+)$/gm;
    const numberedListRegex = /^[\s]*\d+\.\s+(.+)$/gm;

    let lastIndex = 0;
    let match;

    // Extract code blocks
    while ((match = codeBlockRegex.exec(content)) !== null) {
      // Add text before code block
      if (match.index > lastIndex) {
        const textBefore = content.slice(lastIndex, match.index).trim();
        if (textBefore) {
          parts.push({ type: 'text', content: textBefore });
        }
      }

      parts.push({
        type: 'code',
        content: match[2].trim(),
        language: match[1] || 'text'
      });

      lastIndex = match.index + match[0].length;
    }

    // Add remaining text
    if (lastIndex < content.length) {
      const remainingText = content.slice(lastIndex).trim();
      if (remainingText) {
        parts.push({ type: 'text', content: remainingText });
      }
    }

    // Further parse text parts for other structures
    const finalParts: typeof parts = [];
    parts.forEach(part => {
      if (part.type === 'text') {
        // Parse for files, headings, lists, etc.
        const lines = part.content.split('\n');
        let currentSection = '';

        lines.forEach(line => {
          const trimmedLine = line.trim();

          // Check for headings
          const headingMatch = trimmedLine.match(/^(#{1,6})\s+(.+)$/);
          if (headingMatch) {
            if (currentSection) {
              finalParts.push({ type: 'text', content: currentSection.trim() });
              currentSection = '';
            }
            finalParts.push({
              type: 'heading',
              content: headingMatch[2],
              level: headingMatch[1].length
            });
            return;
          }

          // Check for list items
          const listMatch = trimmedLine.match(/^[-*+]\s+(.+)$/) || trimmedLine.match(/^\d+\.\s+(.+)$/);
          if (listMatch) {
            if (currentSection && !currentSection.includes('- ') && !currentSection.match(/\d+\./)) {
              finalParts.push({ type: 'text', content: currentSection.trim() });
              currentSection = '';
            }
            currentSection += line + '\n';
            return;
          }

          // Regular text
          currentSection += line + '\n';
        });

        if (currentSection.trim()) {
          // Check if it's a list
          if (currentSection.includes('- ') || currentSection.match(/\d+\./)) {
            finalParts.push({ type: 'list', content: currentSection.trim() });
          } else {
            finalParts.push({ type: 'text', content: currentSection.trim() });
          }
        }
      } else {
        finalParts.push(part);
      }
    });

    return { parts: finalParts };
  }, [content]);

  const copyToClipboard = async (text: string, blockIndex: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedBlocks(prev => new Set([...Array.from(prev), blockIndex]));
      setTimeout(() => {
        setCopiedBlocks(prev => {
          const newSet = new Set(Array.from(prev));
          newSet.delete(blockIndex);
          return newSet;
        });
      }, 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const createArtifact = (content: string, language: string, filename?: string) => {
    if (!onArtifactCreate) return;

    const artifact: Artifact = {
      id: `artifact-${Date.now()}`,
      name: filename || `${language}_code.${language}`,
      title: filename || `${language} Code`,
      type: language === 'html' ? 'html' : 'code',
      content,
      metadata: {
        language,
        agent,
        timestamp: new Date().toISOString(),
        lines: content.split('\n').length
      }
    };

    onArtifactCreate(artifact);
  };

  const getLanguageIcon = (language: string) => {
    const icons: Record<string, string> = {
      javascript: '🟨',
      typescript: '🔷',
      python: '🐍',
      html: '🌐',
      css: '🎨',
      json: '📋',
      sql: '🗃️',
      shell: '⚡',
      bash: '⚡',
      yaml: '📄',
      xml: '📄'
    };
    return icons[language.toLowerCase()] || '📝';
  };

  const formatList = (content: string) => {
    const lines = content.split('\n').filter(line => line.trim());
    return (
        <ul className="list-disc list-inside space-y-1 ml-4">
          {lines.map((line, index) => {
            const match = line.match(/^[\s]*[-*+]\s+(.+)$/) || line.match(/^[\s]*\d+\.\s+(.+)$/);
            return (
                <li key={index} className="text-gray-700">
                  {match ? match[1] : line.replace(/^[\s]*[-*+]\s*/, '')}
                </li>
            );
          })}
        </ul>
    );
  };

  return (
      <div className="enhanced-message">
        <style>{`
        .enhanced-message {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .code-block {
          background: #f8f9fa;
          border: 1px solid #e9ecef;
          border-radius: 8px;
          overflow: hidden;
          margin: 12px 0;
          font-family: 'Monaco', 'Menlo', monospace;
        }
        
        .code-header {
          background: #e9ecef;
          padding: 8px 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid #dee2e6;
        }
        
        .code-info {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 500;
          color: #495057;
        }
        
        .code-actions {
          display: flex;
          gap: 6px;
        }
        
        .code-action {
          padding: 4px 8px;
          background: white;
          border: 1px solid #ced4da;
          border-radius: 4px;
          font-size: 11px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 4px;
          transition: all 0.2s;
        }
        
        .code-action:hover {
          background: #f8f9fa;
          border-color: #adb5bd;
        }
        
        .code-content {
          padding: 16px;
          overflow-x: auto;
          font-size: 13px;
          line-height: 1.6;
          color: #212529;
          white-space: pre-wrap;
        }
        
        .text-content {
          line-height: 1.6;
          color: #374151;
          margin: 8px 0;
        }
        
        .text-content p {
          margin: 8px 0;
        }
        
        .heading {
          font-weight: 600;
          margin: 16px 0 8px 0;
          color: #1f2937;
        }
        
        .heading-1 { font-size: 24px; }
        .heading-2 { font-size: 20px; }
        .heading-3 { font-size: 18px; }
        .heading-4 { font-size: 16px; }
        .heading-5 { font-size: 14px; }
        .heading-6 { font-size: 12px; }
        
        .artifacts-section {
          margin-top: 16px;
          padding: 12px;
          background: #f0f9ff;
          border: 1px solid #e0f2fe;
          border-radius: 8px;
        }
        
        .artifacts-header {
          font-size: 13px;
          font-weight: 600;
          color: #0369a1;
          margin-bottom: 8px;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        
        .artifact-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 6px 8px;
          background: white;
          border: 1px solid #bae6fd;
          border-radius: 4px;
          margin-bottom: 4px;
        }
        
        .artifact-info {
          flex: 1;
          font-size: 12px;
        }
        
        .artifact-title {
          font-weight: 500;
          color: #0c4a6e;
        }
        
        .artifact-type {
          color: #0369a1;
          text-transform: uppercase;
          font-size: 10px;
        }
        
        .artifact-actions {
          display: flex;
          gap: 4px;
        }
      `}</style>

        {parsedContent.parts && parsedContent.parts.map((part, index) => {
          if (part.type === 'code') {
            const isCopied = copiedBlocks.has(index);
            return (
                <div key={index} className="code-block">
                  <div className="code-header">
                    <div className="code-info">
                      <span>{getLanguageIcon(part.language || 'text')}</span>
                      <span>{part.language || 'text'}</span>
                      {part.filename && <span>• {part.filename}</span>}
                    </div>
                    <div className="code-actions">
                      <button
                          className="code-action"
                          onClick={() => copyToClipboard(part.content, index)}
                      >
                        {isCopied ? <Check size={12} /> : <Copy size={12} />}
                        {isCopied ? 'Copied!' : 'Copy'}
                      </button>
                      {onArtifactCreate && (part.language === 'html' || part.content.length > 100) && (
                          <button
                              className="code-action"
                              onClick={() => createArtifact(part.content, part.language || 'text', part.filename)}
                          >
                            <ExternalLink size={12} />
                            Create Artifact
                          </button>
                      )}
                    </div>
                  </div>
                  <div className="code-content">{part.content}</div>
                </div>
            );
          }

          if (part.type === 'heading') {
            return (
                <div key={index} className={`heading heading-${part.level}`}>
                  {part.content}
                </div>
            );
          }

          if (part.type === 'list') {
            return (
                <div key={index} className="list-content">
                  {formatList(part.content)}
                </div>
            );
          }

          // Regular text
          return (
              <div key={index} className="text-content">
                {part.content.split('\n').map((line, lineIndex) => (
                    <p key={lineIndex}>{line}</p>
                ))}
              </div>
          );
        })}

        {/* Show artifacts if any */}
        {artifacts && artifacts.length > 0 && (
            <div className="artifacts-section">
              <div className="artifacts-header">
                <FileText size={14} />
                Generated Artifacts ({artifacts.length})
              </div>
              {artifacts.map(artifact => (
                  <div key={artifact.id} className="artifact-item">
                    <div className="artifact-info">
                      <div className="artifact-title">{artifact.title}</div>
                      <div className="artifact-type">{artifact.type}</div>
                    </div>
                    <div className="artifact-actions">
                      <button className="code-action">
                        <Eye size={10} />
                        View
                      </button>
                      <button className="code-action">
                        <Download size={10} />
                        Download
                      </button>
                    </div>
                  </div>
              ))}
            </div>
        )}
      </div>
  );
};

export default EnhancedMessage;