import React, { useEffect, useRef } from 'react';
import './ImprovedTimeline.css';

interface TimelineEvent {
  id?: string;
  agent: string;
  action: string;
  status: 'pending' | 'running' | 'complete' | 'error';
  timestamp: Date;
  duration?: number;
  details?: any;
}

interface ImprovedTimelineProps {
  events: TimelineEvent[];
  currentAgent?: string;
  autoScroll?: boolean;
}

const ImprovedTimeline: React.FC<ImprovedTimelineProps> = ({
  events = [],
  currentAgent,
  autoScroll = true
}) => {
  const timelineEndRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new events are added
  useEffect(() => {
    if (autoScroll && timelineEndRef.current) {
      timelineEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [events, autoScroll]);

  // Get agent emoji
  const getAgentEmoji = (agent: string): string => {
    const emojis: Record<string, string> = {
      researcher: '🔬',
      architect: '🏗️',
      developer: '💻',
      designer: '🎨',
      reviewer: '✅',
      tester: '🧪',
      analyst: '📊',
      default: '🤖'
    };
    
    const key = agent.toLowerCase().replace(/[_-]/g, '');
    for (const [k, v] of Object.entries(emojis)) {
      if (key.includes(k)) return v;
    }
    return emojis.default;
  };

  // Get status color
  const getStatusColor = (status: TimelineEvent['status']): string => {
    const colors = {
      pending: '#9ca3af',
      running: '#3b82f6',
      complete: '#10b981',
      error: '#ef4444'
    };
    return colors[status];
  };

  // Get status icon
  const getStatusIcon = (status: TimelineEvent['status']): string => {
    const icons = {
      pending: '⏳',
      running: '⚡',
      complete: '✅',
      error: '❌'
    };
    return icons[status];
  };

  // Format timestamp
  const formatTime = (date: Date): string => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Group events by agent
  const groupedEvents = events.reduce((acc, event) => {
    if (!acc[event.agent]) {
      acc[event.agent] = [];
    }
    acc[event.agent].push(event);
    return acc;
  }, {} as Record<string, TimelineEvent[]>);

  return (
    <div className="improved-timeline-container" ref={containerRef}>
      {/* Header */}
      <div className="timeline-header">
        <h3>📊 Execution Timeline</h3>
        <div className="timeline-stats">
          <span className="stat">
            <span className="stat-label">Events:</span>
            <span className="stat-value">{events.length}</span>
          </span>
          <span className="stat">
            <span className="stat-label">Agents:</span>
            <span className="stat-value">{Object.keys(groupedEvents).length}</span>
          </span>
          {currentAgent && (
            <span className="stat current">
              <span className="stat-label">Active:</span>
              <span className="stat-value">{currentAgent}</span>
            </span>
          )}
        </div>
      </div>

      {/* Timeline Content */}
      <div className="timeline-content">
        {events.length === 0 ? (
          <div className="timeline-empty">
            <span className="empty-icon">⏰</span>
            <p>No events yet. Start an execution to see the timeline.</p>
          </div>
        ) : (
          <>
            {/* Timeline View */}
            <div className="timeline-view">
              {events.map((event, index) => {
                const isActive = event.agent === currentAgent && event.status === 'running';
                const emoji = getAgentEmoji(event.agent);
                const statusColor = getStatusColor(event.status);
                
                return (
                  <div
                    key={event.id || `event-${index}`}
                    className={`timeline-event ${event.status} ${isActive ? 'active' : ''}`}
                  >
                    {/* Timeline Line */}
                    <div className="timeline-line">
                      {index === 0 && <div className="line-start" />}
                      <div 
                        className="event-dot"
                        style={{ backgroundColor: statusColor }}
                      >
                        {event.status === 'running' && (
                          <div className="pulse-ring" />
                        )}
                      </div>
                      {index < events.length - 1 && <div className="line-segment" />}
                    </div>

                    {/* Event Content */}
                    <div className="event-content">
                      <div className="event-header">
                        <div className="event-agent">
                          <span className="agent-emoji">{emoji}</span>
                          <span className="agent-name">{event.agent}</span>
                        </div>
                        <div className="event-meta">
                          <span className="event-status" style={{ color: statusColor }}>
                            {getStatusIcon(event.status)}
                          </span>
                          <span className="event-time">{formatTime(event.timestamp)}</span>
                        </div>
                      </div>
                      
                      <div className="event-action">{event.action}</div>
                      
                      {event.duration && (
                        <div className="event-duration">
                          Duration: {event.duration}ms
                        </div>
                      )}
                      
                      {event.details && (
                        <div className="event-details">
                          <details>
                            <summary>Details</summary>
                            <pre>{JSON.stringify(event.details, null, 2)}</pre>
                          </details>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Agent Summary Sidebar */}
            <div className="agent-summary">
              <h4>Agent Activity</h4>
              <div className="agent-list">
                {Object.entries(groupedEvents).map(([agent, agentEvents]) => {
                  const emoji = getAgentEmoji(agent);
                  const completeCount = agentEvents.filter(e => e.status === 'complete').length;
                  const errorCount = agentEvents.filter(e => e.status === 'error').length;
                  const isCurrentAgent = agent === currentAgent;
                  
                  return (
                    <div 
                      key={agent}
                      className={`agent-summary-item ${isCurrentAgent ? 'current' : ''}`}
                    >
                      <div className="agent-info">
                        <span className="agent-emoji">{emoji}</span>
                        <span className="agent-name">{agent}</span>
                      </div>
                      <div className="agent-stats">
                        <span className="stat-badge total">{agentEvents.length}</span>
                        {completeCount > 0 && (
                          <span className="stat-badge success">{completeCount}</span>
                        )}
                        {errorCount > 0 && (
                          <span className="stat-badge error">{errorCount}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}
        
        {/* Scroll anchor */}
        <div ref={timelineEndRef} />
      </div>
    </div>
  );
};

export default ImprovedTimeline;