import React, { useMemo, useEffect, useState } from 'react';
import './UnifiedAgentPanel.css';

interface Agent {
  id: string;
  name: string;
  role?: string;
  description: string;
  capabilities: string[];
  status: 'idle' | 'thinking' | 'working' | 'streaming' | 'complete' | 'error';
  contributions: number;
  lastActivity?: string;
  currentTask?: string;
  progress?: number;
  tokensUsed?: number;
  toolsUsed?: string[];
  error?: string;
}

interface AgentActivity {
  agentName: string;
  action: string;
  timestamp: Date;
  type: 'handoff' | 'tool' | 'message' | 'complete' | 'error';
  details?: any;
}

interface UnifiedAgentPanelProps {
  agents: Agent[];
  currentAgent?: string;
  activities?: AgentActivity[];
  sharedContext?: Record<string, any>;
  isExecuting?: boolean;
  onAgentSelect?: (agentId: string) => void;
}

const UnifiedAgentPanel: React.FC<UnifiedAgentPanelProps> = ({
  agents,
  currentAgent,
  activities = [],
  sharedContext = {},
  isExecuting = false,
  onAgentSelect
}) => {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['agents']));

  // Reset panel state when execution starts/stops
  useEffect(() => {
    if (!isExecuting) {
      setSelectedAgent(null);
    }
  }, [isExecuting]);

  // Agent emoji mapping
  const getAgentEmoji = (name: string): string => {
    const emojis: Record<string, string> = {
      orchestrator: '🎯',
      researcher: '🔬',
      architect: '🏗️',
      developer: '💻',
      coder: '💻',
      reviewer: '✅',
      analyst: '📊',
      designer: '🎨',
      tester: '🧪',
      documenter: '📝',
      planner: '📋',
      data_scientist: '📈',
      frontend: '🎨',
      backend: '⚙️',
      devops: '🚀',
      security: '🔒',
      database: '🗄️',
      api: '🔌',
      default: '🤖'
    };
    
    const key = name.toLowerCase().replace(/[_-]/g, '').split(/(?=[A-Z])/).join('_').toLowerCase();
    for (const [k, v] of Object.entries(emojis)) {
      if (key.includes(k)) return v;
    }
    return emojis.default;
  };

  // Agent color mapping
  const getAgentColor = (name: string): string => {
    const colors: Record<string, string> = {
      orchestrator: '#6366f1',
      researcher: '#10b981',
      architect: '#8b5cf6',
      developer: '#06b6d4',
      coder: '#06b6d4',
      reviewer: '#f59e0b',
      analyst: '#14b8a6',
      designer: '#ec4899',
      tester: '#ef4444',
      documenter: '#84cc16',
      default: '#6b7280'
    };
    
    const key = name.toLowerCase().replace(/[_-]/g, '');
    for (const [k, v] of Object.entries(colors)) {
      if (key.includes(k)) return v;
    }
    return colors.default;
  };

  // Get status color
  const getStatusColor = (status: Agent['status']): string => {
    const statusColors = {
      idle: '#9ca3af',
      thinking: '#8b5cf6',
      working: '#3b82f6',
      streaming: '#06b6d4',
      complete: '#10b981',
      error: '#ef4444'
    };
    return statusColors[status] || '#6b7280';
  };

  // Get status icon
  const getStatusIcon = (status: Agent['status']): string => {
    const statusIcons = {
      idle: '○',
      thinking: '💭',
      working: '⚡',
      streaming: '✍️',
      complete: '✓',
      error: '✗'
    };
    return statusIcons[status] || '●';
  };

  // Filter active agents (non-idle)
  const activeAgents = useMemo(() => 
    agents.filter(a => a.status !== 'idle' || a.contributions > 0),
    [agents]
  );

  // Get recent activities
  const recentActivities = useMemo(() => 
    activities.slice(-10).reverse(),
    [activities]
  );

  // Calculate team statistics
  const teamStats = useMemo(() => {
    const stats = {
      totalAgents: agents.length,
      activeAgents: agents.filter(a => a.status !== 'idle' && a.status !== 'complete').length,
      completedAgents: agents.filter(a => a.status === 'complete').length,
      totalContributions: agents.reduce((sum, a) => sum + a.contributions, 0),
      totalTokens: agents.reduce((sum, a) => sum + (a.tokensUsed || 0), 0),
      successRate: 0
    };
    
    const completed = agents.filter(a => a.status === 'complete' || a.status === 'error');
    if (completed.length > 0) {
      const successful = completed.filter(a => a.status === 'complete');
      stats.successRate = Math.round((successful.length / completed.length) * 100);
    }
    
    return stats;
  }, [agents]);

  // Toggle section expansion
  const toggleSection = (section: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(section)) {
        next.delete(section);
      } else {
        next.add(section);
      }
      return next;
    });
  };

  // Handle agent selection
  const handleAgentClick = (agentId: string) => {
    setSelectedAgent(selectedAgent === agentId ? null : agentId);
    onAgentSelect?.(agentId);
  };

  // Get selected agent details
  const selectedAgentDetails = useMemo(() => 
    agents.find(a => a.id === selectedAgent),
    [agents, selectedAgent]
  );

  return (
    <div className="unified-agent-panel">
      {/* Team Overview */}
      <div className="team-overview">
        <div className="overview-header">
          <h3>Team Status</h3>
          {isExecuting && <span className="execution-badge">● Executing</span>}
        </div>
        
        <div className="team-stats">
          <div className="stat-item">
            <span className="stat-value">{teamStats.totalAgents}</span>
            <span className="stat-label">Total</span>
          </div>
          <div className="stat-item">
            <span className="stat-value" style={{ color: '#3b82f6' }}>
              {teamStats.activeAgents}
            </span>
            <span className="stat-label">Active</span>
          </div>
          <div className="stat-item">
            <span className="stat-value" style={{ color: '#10b981' }}>
              {teamStats.completedAgents}
            </span>
            <span className="stat-label">Done</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{teamStats.totalContributions}</span>
            <span className="stat-label">Actions</span>
          </div>
          {teamStats.successRate > 0 && (
            <div className="stat-item">
              <span className="stat-value">{teamStats.successRate}%</span>
              <span className="stat-label">Success</span>
            </div>
          )}
        </div>
      </div>

      {/* Active Agents Section */}
      <div className="panel-section">
        <div 
          className="section-header"
          onClick={() => toggleSection('agents')}
        >
          <h4>
            {expandedSections.has('agents') ? '▼' : '▶'} 
            Active Agents ({activeAgents.length})
          </h4>
        </div>
        
        {expandedSections.has('agents') && (
          <div className="agents-container">
            {activeAgents.length === 0 ? (
              <div className="empty-state">
                <span>No active agents yet</span>
              </div>
            ) : (
              activeAgents.map(agent => {
                const isSelected = selectedAgent === agent.id;
                const isCurrent = currentAgent === agent.name;
                const color = getAgentColor(agent.name);
                const emoji = getAgentEmoji(agent.name);
                const statusColor = getStatusColor(agent.status);
                
                return (
                  <div
                    key={agent.id}
                    className={`agent-item ${isSelected ? 'selected' : ''} ${isCurrent ? 'current' : ''}`}
                    onClick={() => handleAgentClick(agent.id)}
                    style={{ '--agent-color': color } as React.CSSProperties}
                  >
                    <div className="agent-main">
                      <div className="agent-avatar" style={{ backgroundColor: color }}>
                        {emoji}
                      </div>
                      
                      <div className="agent-info">
                        <div className="agent-header">
                          <span className="agent-name">{agent.name}</span>
                          <span 
                            className="agent-status"
                            style={{ color: statusColor }}
                          >
                            {getStatusIcon(agent.status)} {agent.status}
                          </span>
                        </div>
                        
                        <div className="agent-description">
                          {agent.currentTask || agent.description}
                        </div>
                        
                        {agent.progress !== undefined && agent.status === 'working' && (
                          <div className="agent-progress">
                            <div 
                              className="progress-bar"
                              style={{ width: `${agent.progress}%`, backgroundColor: color }}
                            />
                          </div>
                        )}
                        
                        <div className="agent-meta">
                          <span>📊 {agent.contributions} actions</span>
                          {agent.tokensUsed && <span>🔤 {agent.tokensUsed} tokens</span>}
                          {agent.toolsUsed && agent.toolsUsed.length > 0 && (
                            <span>🔧 {agent.toolsUsed.length} tools</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {isSelected && selectedAgentDetails && (
                      <div className="agent-details">
                        {selectedAgentDetails.capabilities.length > 0 && (
                          <div className="detail-section">
                            <h5>Capabilities</h5>
                            <div className="capability-tags">
                              {selectedAgentDetails.capabilities.map((cap, idx) => (
                                <span key={idx} className="capability-tag">
                                  {cap}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {selectedAgentDetails.toolsUsed && selectedAgentDetails.toolsUsed.length > 0 && (
                          <div className="detail-section">
                            <h5>Tools Used</h5>
                            <div className="tools-list">
                              {selectedAgentDetails.toolsUsed.map((tool, idx) => (
                                <span key={idx} className="tool-badge">
                                  {tool}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {selectedAgentDetails.error && (
                          <div className="error-message">
                            ⚠️ {selectedAgentDetails.error}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>

      {/* Activity Feed */}
      {recentActivities.length > 0 && (
        <div className="panel-section">
          <div 
            className="section-header"
            onClick={() => toggleSection('activities')}
          >
            <h4>
              {expandedSections.has('activities') ? '▼' : '▶'} 
              Recent Activity
            </h4>
          </div>
          
          {expandedSections.has('activities') && (
            <div className="activity-feed">
              {recentActivities.map((activity, idx) => {
                const agentColor = getAgentColor(activity.agentName);
                const emoji = getAgentEmoji(activity.agentName);
                
                return (
                  <div key={idx} className="activity-item">
                    <div 
                      className="activity-icon"
                      style={{ backgroundColor: agentColor }}
                    >
                      {emoji}
                    </div>
                    <div className="activity-content">
                      <div className="activity-header">
                        <span className="activity-agent">{activity.agentName}</span>
                        <span className="activity-time">
                          {new Date(activity.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="activity-action">{activity.action}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Shared Context */}
      {Object.keys(sharedContext).length > 0 && (
        <div className="panel-section">
          <div 
            className="section-header"
            onClick={() => toggleSection('context')}
          >
            <h4>
              {expandedSections.has('context') ? '▼' : '▶'} 
              Shared Context
            </h4>
          </div>
          
          {expandedSections.has('context') && (
            <div className="shared-context">
              {Object.entries(sharedContext).slice(0, 5).map(([key, value]) => (
                <div key={key} className="context-item">
                  <span className="context-key">{key}:</span>
                  <span className="context-value">
                    {typeof value === 'string' ? value : JSON.stringify(value, null, 2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UnifiedAgentPanel;