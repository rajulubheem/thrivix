import React, { useState, useEffect } from 'react';
import { 
  Clock, Play, CheckCircle, XCircle, AlertCircle,
  Wrench, Brain, ArrowRight, RefreshCw, Zap, MessageSquare
} from 'lucide-react';
import './DynamicAgentTimeline.css';

export interface AgentActivity {
  id: string;
  agent: string;
  type: 'thinking' | 'tool' | 'message' | 'handoff' | 'complete';
  content: string;
  status: 'running' | 'complete' | 'failed';
  timestamp: Date;
  duration?: number;
  tools?: string[];
  metadata?: any;
}

export interface AgentData {
  id: string;
  name: string;
  type: string;
  avatar?: string;
  color?: string;
  status: 'idle' | 'working' | 'complete';
  activities: AgentActivity[];
  tokensUsed?: number;
  contributions?: number;
}

interface DynamicAgentTimelineProps {
  agents: AgentData[];
  handoffs: Array<{ from: string; to: string; count: number; timestamp?: Date }>;
  currentAgent?: string;
  onActivityClick?: (activity: AgentActivity) => void;
}

const DynamicAgentTimeline: React.FC<DynamicAgentTimelineProps> = ({
  agents,
  handoffs,
  currentAgent,
  onActivityClick
}) => {
  const [expandedAgents, setExpandedAgents] = useState<Set<string>>(new Set());
  const [selectedActivity, setSelectedActivity] = useState<string | null>(null);
  
  // Auto-expand current agent
  useEffect(() => {
    if (currentAgent && !expandedAgents.has(currentAgent)) {
      setExpandedAgents(prev => {
        const newSet = new Set(prev);
        newSet.add(currentAgent);
        return newSet;
      });
    }
  }, [currentAgent]);
  
  const toggleAgent = (agentId: string) => {
    setExpandedAgents(prev => {
      const next = new Set(prev);
      if (next.has(agentId)) {
        next.delete(agentId);
      } else {
        next.add(agentId);
      }
      return next;
    });
  };
  
  const getActivityIcon = (type: AgentActivity['type']) => {
    switch (type) {
      case 'thinking': return <Brain size={14} className="icon-thinking" />;
      case 'tool': return <Wrench size={14} className="icon-tool" />;
      case 'message': return <MessageSquare size={14} className="icon-message" />;
      case 'handoff': return <ArrowRight size={14} className="icon-handoff" />;
      case 'complete': return <CheckCircle size={14} className="icon-complete" />;
    }
  };
  
  const getStatusIcon = (status: AgentActivity['status']) => {
    switch (status) {
      case 'running': return <Play size={14} className="status-running" />;
      case 'complete': return <CheckCircle size={14} className="status-complete" />;
      case 'failed': return <XCircle size={14} className="status-failed" />;
    }
  };
  
  const formatDuration = (ms?: number) => {
    if (!ms) return '';
    const seconds = Math.floor(ms / 1000);
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };
  
  const getAgentColor = (agent: AgentData) => {
    return agent.color || '#6366f1';
  };
  
  const getAgentAvatar = (agent: AgentData) => {
    return agent.avatar || '🤖';
  };
  
  // Calculate timeline range
  const activities = agents.flatMap(a => a.activities);
  const minTime = activities.length > 0 
    ? Math.min(...activities.map(a => a.timestamp.getTime()))
    : Date.now();
  const maxTime = activities.length > 0
    ? Math.max(...activities.map(a => a.timestamp.getTime()))
    : Date.now();
  const timeRange = maxTime - minTime || 1000;
  
  return (
    <div className="dynamic-agent-timeline">
      {/* Timeline Header */}
      <div className="timeline-header">
        <h3>Agent Activity Timeline</h3>
        <div className="timeline-stats">
          <span className="stat">
            <Zap size={14} />
            {agents.length} Agents
          </span>
          <span className="stat">
            <ArrowRight size={14} />
            {handoffs.length} Handoffs
          </span>
          <span className="stat">
            <Clock size={14} />
            {formatDuration(timeRange)}
          </span>
        </div>
      </div>
      
      {/* Agent Swimlanes */}
      <div className="agent-swimlanes">
        {agents.map(agent => {
          const isExpanded = expandedAgents.has(agent.id);
          const isActive = currentAgent === agent.id;
          
          return (
            <div 
              key={agent.id} 
              className={`agent-swimlane ${isExpanded ? 'expanded' : ''} ${isActive ? 'active' : ''}`}
            >
              {/* Swimlane Header */}
              <div 
                className="swimlane-header"
                onClick={() => toggleAgent(agent.id)}
                style={{ borderLeftColor: getAgentColor(agent) }}
              >
                <div className="agent-info">
                  <span className="agent-avatar">{getAgentAvatar(agent)}</span>
                  <span className="agent-name">{agent.name}</span>
                  {agent.status === 'working' && (
                    <span className="agent-status working">
                      <Play size={12} /> Working
                    </span>
                  )}
                  {agent.status === 'complete' && (
                    <span className="agent-status complete">
                      <CheckCircle size={12} /> Done
                    </span>
                  )}
                </div>
                <div className="agent-metrics">
                  {agent.activities.length > 0 && (
                    <span className="metric">{agent.activities.length} activities</span>
                  )}
                  {agent.tokensUsed && (
                    <span className="metric">{agent.tokensUsed} tokens</span>
                  )}
                </div>
              </div>
              
              {/* Swimlane Timeline */}
              {isExpanded && (
                <div className="swimlane-timeline">
                  {agent.activities.length === 0 ? (
                    <div className="empty-timeline">
                      <span>No activities yet</span>
                    </div>
                  ) : (
                    <div className="activity-track">
                      {agent.activities.map(activity => {
                        const leftPosition = ((activity.timestamp.getTime() - minTime) / timeRange) * 100;
                        const isSelected = selectedActivity === activity.id;
                        
                        return (
                          <div
                            key={activity.id}
                            className={`activity-node ${activity.type} ${activity.status} ${isSelected ? 'selected' : ''}`}
                            style={{ left: `${leftPosition}%` }}
                            onClick={() => {
                              setSelectedActivity(activity.id);
                              onActivityClick?.(activity);
                            }}
                            title={activity.content}
                          >
                            <div className="activity-icon">
                              {getActivityIcon(activity.type)}
                            </div>
                            <div className="activity-tooltip">
                              <div className="tooltip-header">
                                {getActivityIcon(activity.type)}
                                <span>{activity.type}</span>
                                {getStatusIcon(activity.status)}
                              </div>
                              <div className="tooltip-content">
                                {activity.content}
                              </div>
                              {activity.tools && activity.tools.length > 0 && (
                                <div className="tooltip-tools">
                                  <Wrench size={12} />
                                  {activity.tools.join(', ')}
                                </div>
                              )}
                              <div className="tooltip-time">
                                {activity.timestamp.toLocaleTimeString()}
                                {activity.duration && ` (${formatDuration(activity.duration)})`}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
              
              {/* Handoff Indicators */}
              {handoffs
                .filter(h => h.from === agent.id)
                .map((handoff, idx) => (
                  <div key={idx} className="handoff-indicator">
                    <ArrowRight size={12} />
                    <span>→ {handoff.to} ({handoff.count}x)</span>
                  </div>
                ))}
            </div>
          );
        })}
      </div>
      
      {/* Timeline Scale */}
      <div className="timeline-scale">
        <div className="scale-start">
          {new Date(minTime).toLocaleTimeString()}
        </div>
        <div className="scale-end">
          {new Date(maxTime).toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
};

export default DynamicAgentTimeline;