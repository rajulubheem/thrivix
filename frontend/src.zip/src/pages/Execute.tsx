// Execute.tsx - Fixed version with default agents
import React, { useState } from 'react';
import { SwarmExecutionRequest, Agent } from '../types/swarm';
import { useSwarmExecution } from '../hooks/useSwarmExecution';
import AgentSelector from '../components/swarm/AgentSelector';
import ExecutionTimeline from '../components/swarm/ExecutionTimeline';
import ExecutionResults from '../components/swarm/ExecutionResults';
import './Execute.css';

// Default agents for auto-select mode - Proper Strands swarm without orchestrator
const DEFAULT_AGENTS: Agent[] = [
  {
    name: 'researcher',
    system_prompt: 'You are a research specialist. Analyze requirements and hand off to appropriate specialists.',
    tools: ['web_search'],
    description: 'Research and analyze requirements'
  },
  {
    name: 'architect',
    system_prompt: 'You are a system architect. Design the solution and hand off to developer.',
    tools: [],
    description: 'Design system architecture'
  },
  {
    name: 'developer',
    system_prompt: 'You are a developer. Implement complete working code.',
    tools: ['code_interpreter'],
    description: 'Write and implement code'
  },
  {
    name: 'reviewer',
    system_prompt: 'You are a senior reviewer. Review and compile the final solution.',
    tools: [],
    description: 'Review and provide final assessment'
  }
];

const Execute: React.FC = () => {
  const [task, setTask] = useState('');
  const [selectedAgents, setSelectedAgents] = useState<Agent[]>([]);
  const [isAutoSelect, setIsAutoSelect] = useState(true);
  
  const {
    execute,
    stop,
    isExecuting,
    executionId,
    events,
    result,
    metrics,
    error,
    isConnected
  } = useSwarmExecution();

  const handleExecute = async () => {
    if (!task.trim()) {
      alert('Please enter a task description');
      return;
    }

    // Determine which agents to use
    let agentsToUse: Agent[];
    
    if (isAutoSelect) {
      // Use default agents for auto-select mode
      agentsToUse = DEFAULT_AGENTS;
      console.log('📤 Using default agents for auto-select:', agentsToUse);
    } else {
      // Use manually selected agents
      if (selectedAgents.length === 0) {
        alert('Please select at least one agent or enable auto-select');
        return;
      }
      agentsToUse = selectedAgents;
      console.log('📤 Using selected agents:', agentsToUse);
    }

    const request: SwarmExecutionRequest = {
      task,
      agents: agentsToUse,
      max_handoffs: 20,
      max_iterations: 20,
      execution_timeout: 900,
      node_timeout: 300
    };

    console.log('📤 Sending execution request:', JSON.stringify(request, null, 2));
    
    await execute(request);
  };

  const handleStop = () => {
    if (executionId) {
      stop(executionId);
    }
  };

  return (
    <div className="execute-page">
      {/* Header */}
      <div className="page-header">
        <div className="header-content">
          <h1>Execute Swarm</h1>
          <p>Create and execute multi-agent workflows</p>
        </div>
        <div className="connection-status">
          <span className={`status-badge ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '🟢 Connected' : '🔴 Disconnected'}
          </span>
        </div>
      </div>

      {/* Task Input */}
      <div className="task-section">
        <h3>Task Description</h3>
        <textarea
          placeholder="Describe your task in detail... (e.g., 'Build a REST API for a todo application')"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          className="task-input"
          disabled={isExecuting}
          rows={4}
        />
        
        <div className="task-actions">
          <div className="example-buttons">
            <button
              className="example-btn"
              onClick={() => setTask("Build a REST API for a todo application with user authentication")}
              disabled={isExecuting}
            >
              Example: API
            </button>
            <button
              className="example-btn"
              onClick={() => setTask("Analyze and visualize sales data from the last quarter")}
              disabled={isExecuting}
            >
              Example: Analysis
            </button>
            <button
              className="example-btn"
              onClick={() => setTask("Create a simple hello world application")}
              disabled={isExecuting}
            >
              Example: Simple
            </button>
          </div>
          
          <div className="execute-controls">
            {isExecuting ? (
              <button onClick={handleStop} className="btn btn-stop">
                ⏸️ Stop Execution
              </button>
            ) : (
              <button 
                onClick={handleExecute} 
                disabled={!task.trim()}
                className="btn btn-primary"
              >
                ▶️ Execute Swarm
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Agent Selection */}
      <AgentSelector
        selectedAgents={selectedAgents}
        onSelectionChange={setSelectedAgents}
        isAutoSelect={isAutoSelect}
        onAutoSelectChange={setIsAutoSelect}
        disabled={isExecuting}
      />

      {/* Show which agents will be used */}
      {isAutoSelect && (
        <div className="info-box" style={{ 
          marginTop: '16px', 
          padding: '12px', 
          backgroundColor: '#f0f9ff',
          border: '1px solid #3b82f6',
          borderRadius: '6px'
        }}>
          <strong>ℹ️ Auto-select mode:</strong> Will use default agents (Researcher, Developer)
        </div>
      )}

      {/* Execution View */}
      {(isExecuting || events.length > 0) && (
        <div className="execution-section">
          {/* Metrics */}
          {metrics && (
            <div className="metrics-display">
              <div className="metric-item">
                <span className="metric-label">Agents:</span>
                <span className="metric-value">{metrics.totalAgents}</span>
              </div>
              <div className="metric-item">
                <span className="metric-label">Handoffs:</span>
                <span className="metric-value">{metrics.handoffs}</span>
              </div>
              <div className="metric-item">
                <span className="metric-label">Tool Uses:</span>
                <span className="metric-value">{metrics.toolUses}</span>
              </div>
              <div className="metric-item">
                <span className="metric-label">Events:</span>
                <span className="metric-value">{metrics.events}</span>
              </div>
            </div>
          )}
          
          {/* Execution Timeline */}
          <ExecutionTimeline events={events} isExecuting={isExecuting} />
          
          {/* Results */}
          {result && <ExecutionResults result={result} />}
          
          {/* Error Display */}
          {error && (
            <div className="error-display" style={{
              padding: '16px',
              backgroundColor: '#fee',
              border: '1px solid #f88',
              borderRadius: '6px',
              marginTop: '16px'
            }}>
              <h4>❌ Error</h4>
              <p>{error}</p>
            </div>
          )}
        </div>
      )}

      {/* Empty State */}
      {!isExecuting && events.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">⚡</div>
          <h3>Ready to Execute</h3>
          <p>Enter a task description above and click Execute to begin</p>
          <p style={{ fontSize: '0.875rem', color: '#666', marginTop: '8px' }}>
            {isAutoSelect 
              ? 'Auto-select will use default agents based on your task'
              : `${selectedAgents.length} agent(s) selected`}
          </p>
        </div>
      )}
    </div>
  );
};

export default Execute;