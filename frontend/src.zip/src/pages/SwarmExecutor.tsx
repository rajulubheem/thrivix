import React, { useState, useCallback, useRef, useEffect } from 'react';
import { 
  Play, Pause, StopCircle, Settings, AlertTriangle, CheckCircle, 
  Clock, DollarSign, Zap, Shield, ChevronRight, ChevronDown,
  FileText, Code, Database, TestTube, Search, Brain, GitBranch
} from 'lucide-react';
import { 
  Goal, PlanStep, RunCaps, SwarmExecution, AgentRole, 
  TimelineEntry, SwarmEvent, ApprovalRequest, Recipe,
  AgentConfig, SafetyFlag
} from '../types/swarm-v2';
import { Artifact, convertArtifactRefToArtifact } from '../types/artifacts'; // Import conversion utility
import AgentTimeline from '../components/swarm-v2/AgentTimeline';
import PlanDAGView from '../components/swarm-v2/PlanDAGView';
import ArtifactsPanel from '../components/ArtifactsPanel';
import MetricsPanel from '../components/swarm-v2/MetricsPanel';
import SafetyPanel from '../components/swarm-v2/SafetyPanel';
import ControlPanel from '../components/swarm-v2/ControlPanel';
import ApprovalModal from '../components/swarm-v2/ApprovalModal';
import './SwarmExecutor.css';

// Agent configurations
const AGENT_CONFIGS: Record<AgentRole, AgentConfig> = {
  orchestrator: {
    role: 'orchestrator',
    name: 'Orchestrator',
    avatar: '🎯',
    color: '#6366f1',
    systemPrompt: 'Parse goals, create plans, assign steps, enforce limits',
    tools: ['plan_creator', 'task_assigner', 'limit_enforcer'],
    maxTokens: 2000,
    temperature: 0.3,
    capabilities: ['Planning', 'Task delegation', 'Progress tracking'],
    limitations: ['Cannot execute tools directly']
  },
  researcher: {
    role: 'researcher',
    name: 'Researcher',
    avatar: '🔬',
    color: '#10b981',
    systemPrompt: 'Gather and structure information, provide citations',
    tools: ['web_search', 'document_reader', 'citation_manager'],
    maxTokens: 3000,
    temperature: 0.5,
    capabilities: ['Information gathering', 'Source validation', 'Summarization'],
    limitations: ['Cannot modify code']
  },
  planner: {
    role: 'planner',
    name: 'Planner',
    avatar: '📋',
    color: '#8b5cf6',
    systemPrompt: 'Convert goals to DAG of tasks, handle dependencies',
    tools: ['dag_builder', 'dependency_resolver', 'timeline_estimator'],
    maxTokens: 2000,
    temperature: 0.4,
    capabilities: ['Task decomposition', 'Dependency analysis', 'Timeline planning'],
    limitations: ['Requires orchestrator approval']
  },
  'tool-runner': {
    role: 'tool-runner',
    name: 'Tool Runner',
    avatar: '🔧',
    color: '#f59e0b',
    systemPrompt: 'Execute tools and APIs, retrieve data, handle artifacts',
    tools: ['api_caller', 'file_handler', 'data_processor', 'artifact_manager'],
    maxTokens: 2000,
    temperature: 0.2,
    capabilities: ['API execution', 'Data retrieval', 'File operations'],
    limitations: ['Requires approval for external APIs']
  },
  coder: {
    role: 'coder',
    name: 'Coder',
    avatar: '💻',
    color: '#06b6d4',
    systemPrompt: 'Generate and edit code, create tests, handle diffs',
    tools: ['code_generator', 'test_writer', 'diff_creator', 'linter'],
    maxTokens: 4000,
    temperature: 0.3,
    capabilities: ['Code generation', 'Testing', 'Refactoring'],
    limitations: ['Code execution requires approval']
  },
  reviewer: {
    role: 'reviewer',
    name: 'Reviewer',
    avatar: '✅',
    color: '#ef4444',
    systemPrompt: 'Check outputs against criteria, validate quality, trigger fixes',
    tools: ['quality_checker', 'test_runner', 'criteria_validator'],
    maxTokens: 2000,
    temperature: 0.2,
    capabilities: ['Quality assurance', 'Testing', 'Validation'],
    limitations: ['Cannot directly modify outputs']
  },
  safety: {
    role: 'safety',
    name: 'Safety Officer',
    avatar: '🛡️',
    color: '#dc2626',
    systemPrompt: 'Enforce safety policies, flag risks, protect PII',
    tools: ['policy_checker', 'pii_scanner', 'risk_assessor', 'halt_executor'],
    maxTokens: 1500,
    temperature: 0.1,
    capabilities: ['Risk assessment', 'Policy enforcement', 'Emergency stops'],
    limitations: ['Can halt execution unilaterally']
  }
};

// Sample recipes
const SAMPLE_RECIPES: Recipe[] = [
  {
    id: 'research-draft-review',
    name: 'Research → Draft → Review',
    description: 'Research topic, draft content, and review',
    category: 'content',
    goalTemplate: 'Research {topic} and create a comprehensive report',
    defaultPlan: [],
    defaultCaps: { maxHandoffs: 10, maxRuntimeSec: 600, maxCost: 2, maxRetries: 2, requireApprovals: false, safetyLevel: 'moderate' },
    requiredAgents: ['orchestrator', 'researcher', 'coder', 'reviewer'],
    estimatedTime: 300,
    estimatedCost: 1.5,
    successRate: 0.92,
    usageCount: 45
  },
  {
    id: 'spec-code-test',
    name: 'Spec → Code → Test',
    description: 'Create specification, implement code, and test',
    category: 'development',
    goalTemplate: 'Build a {component} with full test coverage',
    defaultPlan: [],
    defaultCaps: { maxHandoffs: 15, maxRuntimeSec: 900, maxCost: 3, maxRetries: 3, requireApprovals: true, safetyLevel: 'strict' },
    requiredAgents: ['orchestrator', 'planner', 'coder', 'reviewer', 'safety'],
    estimatedTime: 600,
    estimatedCost: 2.5,
    successRate: 0.88,
    usageCount: 123
  }
];

const SwarmExecutor: React.FC = () => {
  // Core state
  const [execution, setExecution] = useState<SwarmExecution | null>(null);
  const [goalInput, setGoalInput] = useState('');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [activeView, setActiveView] = useState<'timeline' | 'dag'>('timeline');
  const [activePanel, setActivePanel] = useState<'artifacts' | 'metrics' | 'safety' | 'logs'>('artifacts');
  
  // UI state
  const [showSettings, setShowSettings] = useState(false);
  const [showApproval, setShowApproval] = useState(false);
  const [currentApproval, setCurrentApproval] = useState<ApprovalRequest | null>(null);
  const [expandedAgents, setExpandedAgents] = useState<Set<AgentRole>>(new Set());
  const [selectedStep, setSelectedStep] = useState<string | null>(null);
  
  // Run caps
  const [runCaps, setRunCaps] = useState<RunCaps>({
    maxHandoffs: 10,
    maxRuntimeSec: 600,
    maxCost: 2.0,
    maxRetries: 2,
    requireApprovals: false,
    safetyLevel: 'moderate'
  });

  // WebSocket ref
  const wsRef = useRef<WebSocket | null>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    connectWebSocket();
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const connectWebSocket = () => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.hostname}:8000/api/v1/ws/swarm-executor`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log('WebSocket connected');
    };

    ws.onmessage = (event) => {
      const swarmEvent: SwarmEvent = JSON.parse(event.data);
      handleSwarmEvent(swarmEvent);
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    ws.onclose = () => {
      console.log('WebSocket disconnected, reconnecting...');
      setTimeout(connectWebSocket, 3000);
    };
  };

  const handleSwarmEvent = (event: SwarmEvent) => {
    console.log('Swarm event:', event);
    
    // Update execution state based on event
    setExecution(prev => {
      if (!prev || prev.id !== event.executionId) return prev;
      
      const updated = { ...prev };
      
      switch (event.type) {
        case 'step_started':
          const stepIdx = updated.plan.findIndex(s => s.id === event.stepId);
          if (stepIdx !== -1) {
            updated.plan[stepIdx].status = 'running';
          }
          break;
          
        case 'step_completed':
          const completedIdx = updated.plan.findIndex(s => s.id === event.stepId);
          if (completedIdx !== -1) {
            updated.plan[completedIdx].status = 'done';
          }
          break;
          
        case 'approval_required':
          setCurrentApproval(event.data as ApprovalRequest);
          setShowApproval(true);
          break;
          
        case 'safety_flag':
          updated.safetyFlags.push(event.data as SafetyFlag);
          break;
          
        case 'metrics_updated':
          updated.metrics = event.data;
          break;
          
        case 'execution_completed':
          updated.status = 'completed';
          updated.endTime = new Date();
          break;
          
        case 'execution_failed':
          updated.status = 'failed';
          updated.error = event.data.error;
          updated.endTime = new Date();
          break;
      }
      
      return updated;
    });
  };

  const handleStart = async () => {
    if (!goalInput.trim()) return;
    
    const goal: Goal = {
      id: `goal-${Date.now()}`,
      text: goalInput,
      constraints: {
        timeMinutes: runCaps.maxRuntimeSec / 60,
        costMax: runCaps.maxCost,
        maxHandoffs: runCaps.maxHandoffs
      },
      acceptance: [],
      createdAt: new Date()
    };

    const newExecution: SwarmExecution = {
      id: `exec-${Date.now()}`,
      goal,
      plan: [],
      runCaps,
      actions: [],
      artifacts: [],
      agentStates: Object.keys(AGENT_CONFIGS).reduce((acc, role) => ({
        ...acc,
        [role]: {
          role: role as AgentRole,
          status: 'idle',
          tokensUsed: 0,
          toolCallsCount: 0,
          handoffsCount: 0
        }
      }), {} as Record<AgentRole, any>),
      handoffHistory: [],
      safetyFlags: [],
      metrics: {
        totalDuration: 0,
        totalCost: 0,
        totalTokens: 0,
        totalToolCalls: 0,
        totalHandoffs: 0,
        successRate: 0,
        retryCount: 0,
        confidenceAvg: 0,
        stepsCompleted: 0,
        stepsTotal: 0,
        artifactsGenerated: 0,
        safetyFlags: 0
      },
      status: 'planning',
      startTime: new Date()
    };

    setExecution(newExecution);
    
    // Send to backend
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'start_execution',
        data: newExecution
      }));
    }
  };

  const handlePause = () => {
    if (!execution) return;
    
    setExecution(prev => prev ? { ...prev, status: 'paused', pausedAt: new Date() } : null);
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'pause_execution',
        executionId: execution.id
      }));
    }
  };

  const handleResume = () => {
    if (!execution) return;
    
    setExecution(prev => prev ? { ...prev, status: 'running', pausedAt: undefined } : null);
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'resume_execution',
        executionId: execution.id
      }));
    }
  };

  const handleStop = () => {
    if (!execution) return;
    
    setExecution(prev => prev ? { 
      ...prev, 
      status: 'cancelled',
      endTime: new Date()
    } : null);
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'stop_execution',
        executionId: execution.id
      }));
    }
  };

  const handleApproval = (approved: boolean, details?: any) => {
    if (!currentApproval || !execution) return;
    
    const response = {
      ...currentApproval,
      status: approved ? 'approved' : 'rejected',
      respondedAt: new Date(),
      ...details
    };
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'approval_response',
        executionId: execution.id,
        data: response
      }));
    }
    
    setShowApproval(false);
    setCurrentApproval(null);
  };

  const toggleAgentExpanded = (agent: AgentRole) => {
    setExpandedAgents(prev => {
      const next = new Set(prev);
      if (next.has(agent)) {
        next.delete(agent);
      } else {
        next.add(agent);
      }
      return next;
    });
  };

  const applyRecipe = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setGoalInput(recipe.goalTemplate);
    setRunCaps(recipe.defaultCaps);
  };

  return (
    <div className="swarm-executor">
      {/* Header */}
      <div className="executor-header">
        <div className="header-left">
          <h1>Swarm Executor</h1>
          <div className="execution-status">
            {execution ? (
              <>
                <span className={`status-badge status-${execution.status}`}>
                  {execution.status}
                </span>
                {execution.startTime && (
                  <span className="runtime">
                    <Clock size={14} />
                    {Math.floor((Date.now() - execution.startTime.getTime()) / 1000)}s
                  </span>
                )}
              </>
            ) : (
              <span className="status-badge status-idle">Ready</span>
            )}
          </div>
        </div>
        
        <div className="header-right">
          <button 
            className="settings-btn"
            onClick={() => setShowSettings(!showSettings)}
          >
            <Settings size={20} />
            Settings
          </button>
        </div>
      </div>

      <div className="executor-layout">
        {/* Left Panel: Chat & Controls */}
        <div className="left-panel">
          <ControlPanel
            goalInput={goalInput}
            setGoalInput={setGoalInput}
            runCaps={runCaps}
            setRunCaps={setRunCaps}
            execution={execution}
            onStart={handleStart}
            onPause={handlePause}
            onResume={handleResume}
            onStop={handleStop}
            recipes={SAMPLE_RECIPES}
            onRecipeSelect={applyRecipe}
            showSettings={showSettings}
          />
        </div>

        {/* Middle Panel: Timeline/DAG View */}
        <div className="middle-panel">
          <div className="view-tabs">
            <button 
              className={`view-tab ${activeView === 'timeline' ? 'active' : ''}`}
              onClick={() => setActiveView('timeline')}
            >
              <Clock size={16} />
              Timeline
            </button>
            <button 
              className={`view-tab ${activeView === 'dag' ? 'active' : ''}`}
              onClick={() => setActiveView('dag')}
            >
              <GitBranch size={16} />
              Plan DAG
            </button>
          </div>

          <div className="view-content">
            {activeView === 'timeline' ? (
              <AgentTimeline
                execution={execution}
                agentConfigs={AGENT_CONFIGS}
                expandedAgents={expandedAgents}
                onToggleAgent={toggleAgentExpanded}
                selectedStep={selectedStep}
                onSelectStep={setSelectedStep}
              />
            ) : (
              <PlanDAGView
                plan={execution?.plan || []}
                selectedStep={selectedStep}
                onSelectStep={setSelectedStep}
                onEditPlan={(plan: PlanStep[]) => setExecution(prev => prev ? {...prev, plan} : null)}
                editable={execution?.status === 'idle' || execution?.status === 'planning'}
              />
            )}
          </div>
        </div>

        {/* Right Panel: Artifacts & Metrics */}
        <div className="right-panel">
          <div className="panel-tabs">
            <button 
              className={`panel-tab ${activePanel === 'artifacts' ? 'active' : ''}`}
              onClick={() => setActivePanel('artifacts')}
            >
              <FileText size={16} />
              Artifacts
            </button>
            <button 
              className={`panel-tab ${activePanel === 'metrics' ? 'active' : ''}`}
              onClick={() => setActivePanel('metrics')}
            >
              <Zap size={16} />
              Metrics
            </button>
            <button 
              className={`panel-tab ${activePanel === 'safety' ? 'active' : ''}`}
              onClick={() => setActivePanel('safety')}
            >
              <Shield size={16} />
              Safety
              {execution && execution.safetyFlags.length > 0 && (
                <span className="badge">{execution.safetyFlags.length}</span>
              )}
            </button>
            <button 
              className={`panel-tab ${activePanel === 'logs' ? 'active' : ''}`}
              onClick={() => setActivePanel('logs')}
            >
              <Code size={16} />
              Logs
            </button>
          </div>

          <div className="panel-content">
            {activePanel === 'artifacts' && (
              <ArtifactsPanel 
                artifacts={execution?.artifacts?.map(convertArtifactRefToArtifact) || []}
                title="Execution Artifacts"
                showActions={true}
              />
            )}
            {activePanel === 'metrics' && execution && (
              <MetricsPanel execution={execution} />
            )}
            {activePanel === 'safety' && (
              <SafetyPanel 
                flags={execution?.safetyFlags || []}
                runCaps={runCaps}
              />
            )}
            {activePanel === 'logs' && (
              <div className="logs-panel">
                {execution?.actions.map(action => (
                  <div key={action.id} className="log-entry">
                    <span className="log-time">
                      {new Date(action.timestamp).toLocaleTimeString()}
                    </span>
                    <span className="log-agent">[{action.agent}]</span>
                    <span className="log-message">{action.type}: {JSON.stringify(action.input)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Approval Modal */}
      {showApproval && currentApproval && (
        <ApprovalModal
          approval={currentApproval}
          onApprove={(details: any) => handleApproval(true, details)}
          onReject={(reason: string) => handleApproval(false, { reason })}
          onClose={() => setShowApproval(false)}
        />
      )}
    </div>
  );
};

export default SwarmExecutor;