import React, { useState, useRef, useEffect } from 'react';
import { SwarmExecutionRequest } from '../types/swarm';
import { useSwarmExecution } from '../hooks/useSwarmExecution';
import './Chat.css';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  artifacts?: any[];
  isStreaming?: boolean;
  error?: string;
}

const Chat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  const {
    execute,
    stop,
    isExecuting,
    executionId,
    events,
    result,
    error,
    isConnected
  } = useSwarmExecution();

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle SSE events
  useEffect(() => {
    if (events.length > 0) {
      const lastEvent = events[events.length - 1];
      
      if (lastEvent.type === 'text_generation' && lastEvent.data?.text) {
        // Update streaming message
        setMessages(prev => {
          const lastMsg = prev[prev.length - 1];
          if (lastMsg && lastMsg.role === 'assistant' && lastMsg.isStreaming) {
            return [
              ...prev.slice(0, -1),
              {
                ...lastMsg,
                content: lastEvent.data.accumulated || lastMsg.content + lastEvent.data.text
              }
            ];
          }
          return prev;
        });
      }
      
      if (lastEvent.type === 'execution_completed' && result) {
        // Finalize the message
        setMessages(prev => {
          const lastMsg = prev[prev.length - 1];
          if (lastMsg && lastMsg.role === 'assistant') {
            return [
              ...prev.slice(0, -1),
              {
                ...lastMsg,
                content: result.result || lastMsg.content,
                artifacts: result.artifacts,
                isStreaming: false
              }
            ];
          }
          return prev;
        });
        setIsTyping(false);
      }
      
      if (lastEvent.type === 'execution_failed') {
        setMessages(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            role: 'system',
            content: `Error: ${lastEvent.data?.error || 'Execution failed'}`,
            timestamp: new Date(),
            error: lastEvent.data?.error
          }
        ]);
        setIsTyping(false);
      }
    }
  }, [events, result]);

  const handleSend = async () => {
    if (!input.trim() || isExecuting) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Add initial assistant message
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isStreaming: true
    };
    setMessages(prev => [...prev, assistantMessage]);

    // Execute swarm
    const request: SwarmExecutionRequest = {
      task: input.trim(),
      agents: [], // Will use default agents
      max_handoffs: 20,
      max_iterations: 20,
      execution_timeout: 900,
      node_timeout: 300
    };

    await execute(request);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleStop = () => {
    if (executionId) {
      stop(executionId);
      setIsTyping(false);
    }
  };

  const formatContent = (content: string) => {
    // Simple markdown-like formatting
    return content
      .split('```')
      .map((part, i) => {
        if (i % 2 === 1) {
          // Code block
          const [lang, ...code] = part.split('\n');
          return (
            <pre key={i} className="code-block">
              <code className={`language-${lang || 'plaintext'}`}>
                {code.join('\n')}
              </code>
            </pre>
          );
        }
        // Regular text with line breaks
        return (
          <span key={i}>
            {part.split('\n').map((line, j) => (
              <React.Fragment key={j}>
                {line}
                {j < part.split('\n').length - 1 && <br />}
              </React.Fragment>
            ))}
          </span>
        );
      });
  };

  return (
    <div className="chat-container">
      <div className="chat-header">
        <div className="chat-title">
          <h1>Strands AI Chat</h1>
          <span className={`connection-badge ${isConnected ? 'connected' : 'disconnected'}`}>
            {isConnected ? '● Connected' : '● Disconnected'}
          </span>
        </div>
        <div className="chat-actions">
          {isExecuting && (
            <button onClick={handleStop} className="stop-button">
              Stop Generation
            </button>
          )}
        </div>
      </div>

      <div className="messages-container">
        {messages.length === 0 && (
          <div className="welcome-message">
            <h2>Welcome to Strands AI Chat</h2>
            <p>Ask me to help you with any task:</p>
            <div className="suggestions">
              <button 
                className="suggestion-chip"
                onClick={() => setInput("Build a REST API for a todo app")}
              >
                Build a REST API
              </button>
              <button 
                className="suggestion-chip"
                onClick={() => setInput("Analyze this data and create visualizations")}
              >
                Data Analysis
              </button>
              <button 
                className="suggestion-chip"
                onClick={() => setInput("Write a Python script to process CSV files")}
              >
                Python Script
              </button>
              <button 
                className="suggestion-chip"
                onClick={() => setInput("Create a React component for a dashboard")}
              >
                React Component
              </button>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <div key={message.id} className={`message ${message.role}`}>
            <div className="message-header">
              <span className="message-role">
                {message.role === 'user' ? '👤' : message.role === 'assistant' ? '🤖' : '⚙️'}
                {' '}
                {message.role.charAt(0).toUpperCase() + message.role.slice(1)}
              </span>
              <span className="message-time">
                {message.timestamp.toLocaleTimeString()}
              </span>
            </div>
            <div className="message-content">
              {message.error ? (
                <div className="error-content">{message.content}</div>
              ) : (
                formatContent(message.content)
              )}
              {message.isStreaming && <span className="typing-indicator">●●●</span>}
            </div>
            {message.artifacts && message.artifacts.length > 0 && (
              <div className="artifacts">
                <div className="artifacts-header">📎 Generated Files:</div>
                {message.artifacts.map((artifact, idx) => (
                  <div key={idx} className="artifact-item">
                    <span className="artifact-name">{artifact.name}</span>
                    <button 
                      className="artifact-action"
                      onClick={() => navigator.clipboard.writeText(artifact.content)}
                    >
                      Copy
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        {isTyping && messages[messages.length - 1]?.role !== 'assistant' && (
          <div className="message assistant">
            <div className="message-header">
              <span className="message-role">🤖 Assistant</span>
            </div>
            <div className="message-content">
              <span className="typing-indicator">●●●</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="input-container">
        <textarea
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message here... (Shift+Enter for new line)"
          className="chat-input"
          disabled={isExecuting}
          rows={1}
        />
        <button 
          onClick={handleSend} 
          disabled={!input.trim() || isExecuting}
          className="send-button"
        >
          {isExecuting ? '⏳' : '➤'}
        </button>
      </div>
    </div>
  );
};

export default Chat;