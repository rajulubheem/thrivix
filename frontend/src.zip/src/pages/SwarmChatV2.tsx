import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useSwarmExecution } from '../hooks/useSwarmExecution';
import { useConversationHistory } from '../hooks/useConversationHistory';
import ArtifactsViewer from '../components/ArtifactsViewer';
import SwarmVisualization from '../components/SwarmVisualization';
import SimpleAgentTimeline from '../components/SimpleAgentTimeline';
import SwarmConversation from '../components/SwarmConversation';
import AgentTeamPanel from '../components/AgentTeamPanel';
import OrchestratorPanel from '../components/OrchestratorPanel';
import AdvancedOrchestratorPanel from '../components/AdvancedOrchestratorPanel';
import { EnhancedOrchestratorPanel } from '../components/EnhancedOrchestratorPanel';
import './SwarmChatV2.css';

// Icon components
const Clock = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10"></circle>
    <polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);

const ChevronDown = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="6 9 12 15 18 9"></polyline>
  </svg>
);

const ChevronRight = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="9 18 15 12 9 6"></polyline>
  </svg>
);

const Eye = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
    <circle cx="12" cy="12" r="3"></circle>
  </svg>
);

const Tool = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
  </svg>
);

const Code = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="16 18 22 12 16 6"></polyline>
    <polyline points="8 6 2 12 8 18"></polyline>
  </svg>
);

const Brain = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 2a9 9 0 0 0-9 9c0 4 3 7 3 7s1.5-2 3-2 3 2 3 2 3-2 3-2 1.5 2 3 2 3-3 3-7a9 9 0 0 0-9-9z"></path>
  </svg>
);

const Send = ({ size = 20 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);

interface AgentProfile {
  name: string;
  avatar: string;
  color: string;
}

const AGENT_PROFILES: Record<string, AgentProfile> = {
  researcher: { name: 'Researcher', avatar: '🔬', color: '#6366f1' },
  architect: { name: 'Architect', avatar: '🏗️', color: '#8b5cf6' },
  developer: { name: 'Developer', avatar: '💻', color: '#10b981' },
  reviewer: { name: 'Reviewer', avatar: '✅', color: '#f59e0b' },
  tester: { name: 'Tester', avatar: '🧪', color: '#ef4444' },
  data_scientist: { name: 'Data Scientist', avatar: '📊', color: '#06b6d4' },
  devops: { name: 'DevOps', avatar: '🚀', color: '#84cc16' }
};

interface CodeBlock {
  name: string;
  language: string;
  content: string;
  description?: string;
}

interface AgentMessage {
  id: string;
  agent: string;
  content: string;
  streamingContent?: string;
  thinking?: string[];
  tools?: Array<{ name: string; status: 'running' | 'complete' }>;
  codeBlocks?: CodeBlock[];
  status: 'thinking' | 'working' | 'streaming' | 'complete';
  timestamp: Date;
}

interface UserMessage {
  id: string;
  content: string;
  timestamp: Date;
}

const SwarmChatV2: React.FC = () => {
  const [input, setInput] = useState('');
  const [userMessages, setUserMessages] = useState<UserMessage[]>([]);
  const [agentMessages, setAgentMessages] = useState<AgentMessage[]>([]);
  const [conversationItems, setConversationItems] = useState<any[]>([]);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());
  const [swarmData, setSwarmData] = useState<{
    agents: any[];
    handoffs: any[];
    currentAgent?: string;
    sharedMemory?: any;
    sharedKnowledge?: Record<string, any>;
  }>({
    agents: [],
    handoffs: [],
    sharedKnowledge: {}
  });
  const [dynamicAgents, setDynamicAgents] = useState<any[]>([]);
  const [timelineEvents, setTimelineEvents] = useState<any[]>([]);
  const [selectedView, setSelectedView] = useState<'conversation' | 'timeline' | 'visualization' | 'team' | 'orchestrator' | 'advanced' | 'enhanced'>('conversation');
  const [customAgents, setCustomAgents] = useState<any[]>([]);
  const [currentWorkflow, setCurrentWorkflow] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const streamBufferRef = useRef<Map<string, string>>(new Map());
  const streamTimerRef = useRef<Map<string, NodeJS.Timeout>>(new Map());
  
  const { execute, events, isExecuting, isConnected, result, error } = useSwarmExecution();
  const { 
    currentSessionId,
    createSession,
    addMessage,
    addAgent,
    updateSession,
    getRecentSessions,
    setCurrentSessionId
  } = useConversationHistory();
  

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      streamTimerRef.current.forEach(timer => clearTimeout(timer));
      streamTimerRef.current.clear();
      streamBufferRef.current.clear();
    };
  }, []);

  // Log execution result and errors
  useEffect(() => {
    if (result) {
      console.log('[SwarmChatV2] Execution completed with result:', result);
    }
  }, [result]);
  
  useEffect(() => {
    if (error) {
      console.error('[SwarmChatV2] Execution error:', error);
    }
  }, [error]);
  
  // Track processed events across renders
  const processedEventsRef = useRef<Set<string>>(new Set());
  const lastEventCountRef = useRef<number>(0);
  
  // Process events
  useEffect(() => {
    // Only process new events
    if (events.length <= lastEventCountRef.current) return;
    
    const newEvents = events.slice(lastEventCountRef.current);
    lastEventCountRef.current = events.length;
    
    console.log(`[SwarmChatV2] Processing ${newEvents.length} new events (total: ${events.length})`);
    
    newEvents.forEach(event => {
      const eventKey = `${event.type}-${event.timestamp}-${event.agent || 'system'}`;
      
      // Skip if already processed
      if (processedEventsRef.current.has(eventKey)) {
        console.log(`[SwarmChatV2] Skipping duplicate event: ${eventKey}`);
        return;
      }
      processedEventsRef.current.add(eventKey);
      
      // console.log(`[SwarmChatV2] Processing event: ${event.type}`, event);
      
      switch (event.type) {
        case 'handoff':
          // Show handoff message between agents
          if (event.data) {
            const { from_agent, to_agent, handoff_count, reason, shared_knowledge } = event.data;
            console.log(`Handoff #${handoff_count}: ${from_agent} -> ${to_agent}`);
            
            // Add to conversation
            setConversationItems(prev => [...prev, {
              id: `handoff-${Date.now()}`,
              type: 'handoff',
              content: '',
              timestamp: new Date(),
              metadata: {
                fromAgent: from_agent,
                toAgent: to_agent,
                reason: reason || `Agent ${from_agent} needs ${to_agent}'s expertise`,
                sharedKnowledge: shared_knowledge
              }
            }]);
            
            // Update shared knowledge
            if (shared_knowledge) {
              setSwarmData(prev => ({
                ...prev,
                sharedKnowledge: {
                  ...prev.sharedKnowledge,
                  [from_agent]: shared_knowledge
                }
              }));
            }
            
            // Mark previous agent as complete in timeline
            setTimelineEvents(prev => {
              const updatedEvents = [...prev];
              // Find last event for from_agent and mark complete
              for (let i = updatedEvents.length - 1; i >= 0; i--) {
                if (updatedEvents[i].agent === from_agent && updatedEvents[i].status === 'running') {
                  updatedEvents[i] = {
                    ...updatedEvents[i],
                    status: 'complete' as const
                  };
                  break;
                }
              }
              
              // Add handoff event
              updatedEvents.push({
                agent: from_agent,
                action: `Handing off to ${to_agent}`,
                status: 'complete' as const,
                timestamp: new Date()
              });
              
              return updatedEvents;
            });
            
            // Update swarm visualization
            setSwarmData(prev => {
              const handoffs = [...prev.handoffs];
              const existingHandoff = handoffs.find(h => h.from === from_agent && h.to === to_agent);
              
              if (existingHandoff) {
                existingHandoff.count++;
              } else {
                handoffs.push({ from: from_agent, to: to_agent, count: 1 });
              }
              
              return {
                ...prev,
                handoffs,
                currentAgent: to_agent
              };
            });
          }
          break;
          
        case 'system_message':
          // Show system messages (like loop prevention)
          if (event.data?.message) {
            console.log('System:', event.data.message);
          }
          break;
          
        case 'agent_started':
          if (event.agent) {
            const agentName = event.agent;
            
            // Update or add to dynamic agents
            setDynamicAgents(prev => {
              const existingIndex = prev.findIndex(a => a.name === agentName);
              
              // Check if this is an orchestrator agent
              const isOrchestratorAgent = prev.some(a => 
                a.name === agentName && a.created_by === 'orchestrator'
              );
              
              if (existingIndex === -1) {
                // Only add if it's not already in the list
                // Extract agent info from event data
                const agentInfo = event.data?.agent_info || {};
                
                // Don't add default swarm agents if we have orchestrator agents
                const hasOrchestratorAgents = prev.some(a => a.created_by === 'orchestrator');
                if (hasOrchestratorAgents && !isOrchestratorAgent) {
                  // This is likely a default agent, skip it
                  console.log(`Skipping default agent ${agentName} - using orchestrator agents`);
                  return prev;
                }
                
                return [...prev, {
                  id: agentName,
                  name: agentName,
                  description: agentInfo.description || event.data?.description || `${agentName} specialist`,
                  capabilities: agentInfo.capabilities || event.data?.capabilities || [],
                  status: 'working',
                  contributions: 0,
                  lastActivity: 'Starting task',
                  created_by: 'swarm'  // Mark as swarm-created if not orchestrator
                }];
              } else {
                // Update existing agent status
                const updated = [...prev];
                updated[existingIndex] = {
                  ...updated[existingIndex],
                  status: 'working',
                  lastActivity: 'Working on task'
                };
                return updated;
              }
            });
            
            // Only add to conversation if this is truly a new agent starting
            setConversationItems(prev => {
              const lastAgentItem = [...prev].reverse().find(item => 
                item.type === 'agent' && item.agent === agentName
              );
              
              // Don't add if we just added this agent recently
              if (lastAgentItem && (Date.now() - new Date(lastAgentItem.timestamp).getTime() < 5000)) {
                return prev;
              }
              
              return [...prev, {
                id: `${agentName}-${event.timestamp}`,
                type: 'agent',
                agent: agentName,
                content: 'Starting task analysis...',
                timestamp: new Date(),
                metadata: {
                  toolsUsed: [],
                  availableAgents: event.data?.available_agents
                }
              }];
            });
            
            // Only add agent message if doesn't exist
            setAgentMessages(prev => {
              const hasMessage = prev.some(m => 
                m.agent === agentName && (m.status === 'thinking' || m.status === 'streaming' || m.status === 'working')
              );
              
              if (!hasMessage) {
                return [...prev, {
                  id: `${agentName}-${event.timestamp}`,
                  agent: agentName,
                  content: '',
                  streamingContent: '',
                  thinking: [],
                  tools: [],
                  codeBlocks: [],
                  status: 'thinking' as const,
                  timestamp: new Date()
                }];
              }
              return prev;
            });
            
            // Update swarm visualization
            setSwarmData(prev => {
              const agents = [...prev.agents];
              const existingAgent = agents.find(a => a.id === agentName);
              
              if (!existingAgent) {
                agents.push({
                  id: agentName,
                  name: agentName,
                  type: agentName,
                  status: 'working',
                  contributions: 0
                });
              } else {
                existingAgent.status = 'working';
              }
              
              return {
                ...prev,
                agents,
                currentAgent: agentName
              };
            });
            
            // Add timeline event only if not duplicate
            setTimelineEvents(prev => {
              // Check if agent already has a recent running event
              const hasRecentRunning = prev.some(e => 
                e.agent === agentName && 
                e.status === 'running' &&
                (Date.now() - new Date(e.timestamp).getTime() < 10000) // Within 10 seconds
              );
              
              if (hasRecentRunning) {
                return prev;
              }
              
              // Check if this is an orchestrator-created agent
              const orchestratorAgent = dynamicAgents.find(a => 
                a.name === agentName && a.created_by === 'orchestrator'
              );
              
              const action = orchestratorAgent 
                ? `🎭 ${agentName} started (Orchestrator Agent: ${orchestratorAgent.description?.substring(0, 50)}...)`
                : `Started working`;
              
              return [...prev, {
                agent: agentName,
                action: action,
                status: 'running' as const,
                timestamp: new Date()
              }];
            });
          }
          break;
          
        case 'text_generation':
          if (event.agent && event.data) {
            const agentName = event.agent;
            const accumulated = event.data.accumulated || '';
            
            // Buffer the streaming content for smoother updates
            streamBufferRef.current.set(agentName, accumulated);
            
            // Clear existing timer for this agent
            const existingTimer = streamTimerRef.current.get(agentName);
            if (existingTimer) {
              clearTimeout(existingTimer);
            }
            
            // Process immediately instead of delaying (fixes batch processing issue)
            const bufferedContent = accumulated || streamBufferRef.current.get(agentName) || '';
            
            // Update conversation items immediately
              setConversationItems(prev => {
                // Find the last agent response for this agent
                let lastIndex = -1;
                for (let i = prev.length - 1; i >= 0; i--) {
                  if (prev[i].type === 'agent' && prev[i].agent === agentName) {
                    lastIndex = i;
                    break;
                  }
                }
                
                if (lastIndex !== -1) {
                  const updated = [...prev];
                  updated[lastIndex] = {
                    ...updated[lastIndex],
                    content: bufferedContent
                  };
                  return updated;
                }
                return prev;
              });
              
              setAgentMessages(prev => {
                const msgIndex = prev.findIndex(m => 
                  m.agent === agentName && m.status !== 'complete'
                );
                
                // console.log(`[SwarmChatV2] text_generation for ${agentName}:`, {
                //   msgIndex,
                //   existingMessages: prev.length,
                //   bufferedContent: bufferedContent.substring(0, 50) + '...'
                // });
                
                if (msgIndex !== -1) {
                  const updated = [...prev];
                  updated[msgIndex] = {
                    ...updated[msgIndex],
                    content: bufferedContent,
                    streamingContent: bufferedContent,
                    status: 'streaming' as const
                  };
                  // console.log(`[SwarmChatV2] Updated existing message for ${agentName}`);
                  return updated;
                } else {
                  // Create new message if doesn't exist
                  // console.log(`[SwarmChatV2] Creating new message for ${agentName}`);
                  return [...prev, {
                    id: `${agentName}-${Date.now()}`,
                    agent: agentName,
                    content: bufferedContent,
                    streamingContent: bufferedContent,
                    thinking: [],
                    tools: [],
                    codeBlocks: [],
                    status: 'streaming' as const,
                    timestamp: new Date()
                  }];
                }
              });
            // No longer using setTimeout to avoid missing batch-processed events
          }
          break;
          
        case 'tool_use':
          if (event.agent && event.data?.tool) {
            const agentName = event.agent;
            const toolName = event.data.tool;
            
            // Update agent message with tool use
            setAgentMessages(prev => {
              const msgIndex = prev.findIndex(m => 
                m.agent === agentName && m.status !== 'complete'
              );
              
              if (msgIndex !== -1) {
                const updated = [...prev];
                const tools = updated[msgIndex].tools || [];
                tools.push({ 
                  name: toolName, 
                  status: 'running' as const
                });
                updated[msgIndex] = {
                  ...updated[msgIndex],
                  tools
                };
                return updated;
              }
              return prev;
            });
            
            // Add tool use to timeline
            setTimelineEvents(prev => [...prev, {
              agent: agentName,
              action: `Using tool: ${toolName}`,
              status: 'running' as const,
              timestamp: new Date()
            }]);
          }
          break;
          
        case 'agent_completed':
          if (event.agent) {
            const agentName = event.agent;
            
            // Update dynamic agents
            setDynamicAgents(prev => prev.map(a => 
              a.name === agentName 
                ? { ...a, status: 'complete', contributions: a.contributions + 1, lastActivity: 'Completed task' }
                : a
            ));
            
            // Clear streaming timer for this agent
            const timer = streamTimerRef.current.get(agentName);
            if (timer) {
              clearTimeout(timer);
              streamTimerRef.current.delete(agentName);
            }
            streamBufferRef.current.delete(agentName);
            
            setAgentMessages(prev => {
              const msgIndex = prev.findIndex(m => 
                m.agent === agentName && m.status !== 'complete'
              );
              
              if (msgIndex !== -1) {
                const updated = [...prev];
                // Move streaming content to final content
                updated[msgIndex] = {
                  ...updated[msgIndex],
                  content: updated[msgIndex].streamingContent || '',
                  streamingContent: '',
                  status: 'complete' as const,
                  tools: updated[msgIndex].tools?.map(t => ({ ...t, status: 'complete' as const }))
                };
                
                // Extract code blocks from content
                const codeBlocks = extractCodeBlocks(updated[msgIndex].content);
                if (codeBlocks.length > 0) {
                  updated[msgIndex].codeBlocks = codeBlocks;
                  // Remove code blocks from main content for cleaner display
                  updated[msgIndex].content = removeCodeBlocks(updated[msgIndex].content);
                }
                
                return updated;
              }
              return prev;
            });
            
            // Update timeline - mark agent as complete
            setTimelineEvents(prev => {
              const updatedEvents = [...prev];
              // Find all running events for this agent and mark complete
              for (let i = updatedEvents.length - 1; i >= 0; i--) {
                if (updatedEvents[i].agent === agentName && updatedEvents[i].status === 'running') {
                  updatedEvents[i] = {
                    ...updatedEvents[i],
                    status: 'complete' as const
                  };
                }
              }
              
              // Add completion event
              updatedEvents.push({
                agent: agentName,
                action: `${agentName} completed task`,
                status: 'complete' as const,
                timestamp: new Date()
              });
              
              return updatedEvents;
            });
            
            // Update swarm visualization
            setSwarmData(prev => {
              const agents = [...prev.agents];
              const agent = agents.find(a => a.id === agentName);
              
              if (agent) {
                agent.status = 'complete';
                agent.contributions++;
              }
              
              return {
                ...prev,
                agents,
                currentAgent: undefined
              };
            });
          }
          break;
      }
    });
  }, [events]);
  
  // Extract code blocks from content with better parsing
  const extractCodeBlocks = (content: string): CodeBlock[] => {
    const codeBlockRegex = /```(\w+)?\s*(?:\/\/\s*(.+?)\n)?([\s\S]*?)```/g;
    const blocks: CodeBlock[] = [];
    let match;
    
    while ((match = codeBlockRegex.exec(content)) !== null) {
      const language = match[1] || 'text';
      const codeContent = match[3].trim();
      const fileName: string = match[2] || detectFileName(codeContent, language, blocks.length);
      
      if (codeContent.length > 0) {
        blocks.push({
          name: fileName,
          language: language,
          content: codeContent,
          description: getFileDescription(fileName)
        });
      }
    }
    
    return blocks;
  };
  
  // Detect filename from code content
  const detectFileName = (code: string, language: string, index: number): string => {
    // Check for common patterns in code
    if (code.includes('express()') || code.includes('app.listen')) {
      return 'server.js';
    }
    if (code.includes('mongoose.model') || code.includes('Schema')) {
      return 'models/Todo.js';
    }
    if (code.includes('router.') || code.includes('router.get')) {
      return 'routes/todos.js';
    }
    if (code.includes('"name"') && code.includes('"version"') && language === 'json') {
      return 'package.json';
    }
    if (code.includes('DATABASE_URL') || code.includes('JWT_SECRET')) {
      return '.env.example';
    }
    
    // Default naming
    const extensions: Record<string, string> = {
      javascript: 'js',
      typescript: 'ts',
      python: 'py',
      json: 'json',
      bash: 'sh',
      sql: 'sql',
      html: 'html',
      css: 'css'
    };
    
    const ext = extensions[language] || 'txt';
    return `file_${index + 1}.${ext}`;
  };
  
  // Get description for common files
  const getFileDescription = (fileName: string) => {
    const descriptions: Record<string, string> = {
      'server.js': 'Main server file with Express setup',
      'package.json': 'Node.js dependencies and scripts',
      'routes/todos.js': 'Todo API route handlers',
      'models/Todo.js': 'Todo data model schema',
      '.env.example': 'Environment variables template'
    };
    return descriptions[fileName] || '';
  };
  
  // Remove code blocks from content
  const removeCodeBlocks = (content: string) => {
    return content.replace(/```(\w+)?\n[\s\S]*?```/g, '[Code block]').trim();
  };
  
  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [agentMessages, userMessages]);
  
  // Toggle section expansion
  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(sectionId)) {
        next.delete(sectionId);
      } else {
        next.add(sectionId);
      }
      return next;
    });
  };
  
  // Send message
  // Handler for ADVANCED workflow execution with shared memory
  const handleAdvancedWorkflowStart = async (workflow: any) => {
    console.log('🚀 Starting ADVANCED workflow:', workflow);
    setCurrentWorkflow(workflow);
    
    // Create advanced agents with tools and shared memory
    const advancedAgents = workflow.tasks.map((task: any, idx: number) => {
      const nextAgent = idx < workflow.tasks.length - 1 
        ? workflow.tasks[idx + 1].agent_type 
        : null;
      
      // Advanced Strands agent prompt with proper tools and state management
      const advancedPrompt = `You are ${task.agent_type} - ${task.description}

AVAILABLE STRANDS TOOLS: ${task.tools.join(', ')}

YOUR MISSION: 
${task.system_prompt}

STRANDS AGENT WORKFLOW:
1. Use agent.state.get() to read shared context from previous agents
2. Execute your tools to complete your specific tasks:
${task.tools.map((tool: string) => {
  switch(tool) {
    case 'file_write': return '   - Use file_write to create actual files and code';
    case 'python_repl': return '   - Use python_repl to run Python code and calculations';
    case 'shell': return '   - Use shell to execute system commands';
    case 'http_request': return '   - Use http_request to fetch data from APIs';
    case 'diagram': return '   - Use diagram to create technical diagrams';
    case 'calculator': return '   - Use calculator for mathematical calculations';
    case 'code_interpreter': return '   - Use code_interpreter for safe code execution';
    case 'generate_image': return '   - Use generate_image to create visual mockups';
    default: return `   - Use ${tool} for your specialized tasks`;
  }
}).join('\n')}

3. Save your work and findings to agent.state using:
   - agent.state.set(key, value) for each shared memory key
   - Store results for: ${task.shared_memory_keys.join(', ')}

REQUIRED DELIVERABLES:
${task.output_artifacts.map((artifact: string) => `- Create file: ${artifact}`).join('\n')}

${nextAgent ? `
HANDOFF TO ${nextAgent}:
- Complete all your tasks and file creation
- Save findings to agent state for next agent to access
- Use swarm coordination for seamless handoff` : 
'FINAL AGENT: Complete all tasks and provide comprehensive summary'}

EXECUTE TOOLS NOW - CREATE REAL FILES AND CODE!`;
      
      return {
        name: task.agent_type,
        system_prompt: advancedPrompt,
        tools: [...task.tools, 'swarm', 'memory'], // Add swarm coordination and memory
        model_id: 'gpt-4',
        description: task.description,
        icon: '🚀'
      };
    });
    
    // Create workflow context for shared memory
    const workflowContext = {
      shared_memory: {},
      context_flow: workflow.context_flow,
      artifacts: [],
      task_count: workflow.tasks.length
    };
    
    // Advanced Strands workflow with proper state management and tools
    const advancedTaskDescription = `
🚀 STRANDS ADVANCED PROJECT: ${workflow.description}

This is a sophisticated Strands multi-agent workflow with state management and real file creation.

STRANDS AGENT COORDINATION (${workflow.tasks.length} SPECIALIZED AGENTS):
${workflow.tasks.map((t: any, idx: number) => `
${idx + 1}. ${t.agent_type}
   TOOLS: ${t.tools.join(', ')}
   CREATES: ${t.output_artifacts.join(', ')}
   SHARES: ${t.shared_memory_keys.join(', ')}
   MISSION: ${t.description}
`).join('')}

STRANDS WORKFLOW EXECUTION:
1. Each agent has access to powerful Strands tools for real work
2. Use agent.state.get/set() for shared context between agents  
3. Create actual files using file_write, run code with python_repl
4. Generate diagrams, images, and documentation
5. Coordinate through swarm architecture

AGENT ${workflow.tasks[0].agent_type} - START EXECUTION:
- Access your Strands tools: ${workflow.tasks[0].tools.join(', ')}
- Create real files: ${workflow.tasks[0].output_artifacts.join(', ')}
- Save findings to agent.state for next agent
- Hand off to ${workflow.tasks.length > 1 ? workflow.tasks[1].agent_type : 'completion'}

CRITICAL: Use actual Strands tools - file_write, python_repl, shell, diagram, etc.
This creates a REAL project with actual files, code, and documentation.

Execute all ${workflow.tasks.length} agents with full Strands capabilities!`;
    
    // Reset for new execution but preserve some context
    setTimelineEvents([]);
    processedEventsRef.current.clear();
    lastEventCountRef.current = 0;
    
    // Create session
    const sessionId = createSession(workflow.name);
    
    // Initialize conversation with workflow start
    const initialMessages = [
      {
        id: `user-workflow-${Date.now()}`,
        type: 'user',
        content: `Execute advanced workflow: ${workflow.description}`,
        timestamp: new Date()
      },
      {
        id: `adv-workflow-${Date.now()}`,
        type: 'system',
        content: `🚀 Advanced Orchestrator: Launching ${advancedAgents.length} expert agents with tools and shared memory`,
        timestamp: new Date()
      }
    ];
    
    setConversationItems(initialMessages);
    setUserMessages([initialMessages[0]]);
    setAgentMessages([]);
    
    // Show agent capabilities
    const capabilitiesMessage = {
      id: `capabilities-${Date.now()}`,
      type: 'system',
      content: `📊 Workflow Capabilities:
• ${workflow.tasks.reduce((acc: number, t: any) => acc + t.tools.length, 0)} Total Tools
• ${workflow.tasks.reduce((acc: number, t: any) => acc + t.output_artifacts.length, 0)} Artifacts to Generate
• ${Array.from(new Set(workflow.tasks.flatMap((t: any) => t.shared_memory_keys))).length} Shared Memory Keys
• Full Production Implementation`,
      timestamp: new Date()
    };
    
    setConversationItems(prev => [...prev, capabilitiesMessage]);
    
    // Execute with advanced configuration
    console.log('🚀 Executing ADVANCED workflow with:', {
      agents: advancedAgents.length,
      tools: advancedAgents.flatMap((a: any) => a.tools),
      shared_memory_keys: Array.from(new Set(workflow.tasks.flatMap((t: any) => t.shared_memory_keys)))
    });
    
    console.log('🚀 Starting execution with task:', advancedTaskDescription);
    console.log('🚀 Agents to execute:', advancedAgents);
    
    await execute({
      task: advancedTaskDescription,
      agents: advancedAgents,
      max_handoffs: 20,  // Increase handoffs to ensure all agents execute
      max_iterations: 20,
      execution_timeout: 1200,  // 20 minutes total
      node_timeout: 240,  // 4 minutes per agent
      background: false  // Ensure synchronous execution
    });
  };

  // Handler for workflow execution from orchestrator
  const handleWorkflowStart = async (workflow: any) => {
    console.log('[SwarmChatV2] Starting workflow:', workflow);
    setCurrentWorkflow(workflow);
    
    // Create dynamic agents from the workflow plan
    const workflowAgents = workflow.tasks.map((task: any) => ({
      id: `agent-${task.task_id}`,
      name: task.agent_type,
      description: task.system_prompt,
      capabilities: task.system_prompt.match(/[A-Z][a-z]+/g) || [],
      status: 'idle',
      contributions: 0,
      created_by: 'orchestrator',
      task_id: task.task_id
    }));
    
    // Add workflow agents to dynamic agents (preserving custom agents)
    setDynamicAgents(prev => {
      // Keep custom user-created agents
      const userAgents = prev.filter(a => a.created_by === 'user');
      // Add new workflow agents
      return [...userAgents, ...workflowAgents];
    });
    
    // Create Agent objects for the swarm execution from workflow tasks
    // Include workflow enforcement in each agent's prompt
    const orchestratorAgents = workflow.tasks.map((task: any, idx: number) => {
      const nextAgent = idx < workflow.tasks.length - 1 
        ? workflow.tasks[idx + 1].agent_type 
        : null;
      
      const workflowPrompt = `
${task.system_prompt}

You are step ${idx + 1} of ${workflow.tasks.length} in this workflow.
${nextAgent 
  ? `CRITICAL: After completing your work, the next agent ${nextAgent} MUST continue the workflow. Pass control to ${nextAgent}.`
  : `You are the FINAL step. After completing documentation, the workflow is done.`}
`;
      
      return {
        name: task.agent_type,
        system_prompt: workflowPrompt,
        tools: [], // Tools will be determined by the backend based on agent type
        model_id: 'gpt-4', // Default model, can be customized
        description: task.description,
        icon: '🎭'
      };
    });
    
    // Build a task description that enforces complete workflow execution
    const taskDescription = `
Task: ${workflow.description}

IMPORTANT: This is a ${workflow.tasks.length}-step workflow. ALL steps MUST be completed.

Execute these agents IN ORDER:
${workflow.tasks.map((t: any, idx: number) => 
  `${idx + 1}. ${t.agent_type}: ${t.description}`
).join('\n')}

The task is NOT complete until ALL ${workflow.tasks.length} agents have executed.
Continue executing agents until ${workflow.tasks[workflow.tasks.length - 1].agent_type} completes the documentation.
`;
    
    // Clear previous conversation but preserve custom agents
    setConversationItems([]);
    setUserMessages([]);
    setAgentMessages([]);
    setTimelineEvents([]);
    processedEventsRef.current.clear();
    lastEventCountRef.current = 0;
    
    // Create session and execute
    const sessionId = createSession(workflow.name);
    
    // Add orchestrator announcement
    setConversationItems([{
      id: `workflow-${Date.now()}`,
      type: 'system',
      content: `🎭 Orchestrator: Starting workflow "${workflow.name}" with ${orchestratorAgents.length} specialized agents`,
      timestamp: new Date()
    }]);
    
    // Add visual representation of orchestrator agents being deployed
    const agentDeployment = {
      id: `deployment-${Date.now()}`,
      type: 'system',
      content: `📋 Deploying Orchestrator Agents:\n${orchestratorAgents.map((a: any) => 
        `• ${a.name}: ${a.description}`
      ).join('\n')}`,
      timestamp: new Date()
    };
    
    setConversationItems(prev => [...prev, agentDeployment]);
    
    // Execute the workflow WITH the orchestrator-created agents
    console.log('🎭 Executing with Orchestrator Agents:', orchestratorAgents);
    
    await execute({
      task: taskDescription,
      agents: orchestratorAgents,  // Pass the orchestrator-created agents!
      max_handoffs: 30,
      max_iterations: 30,
      execution_timeout: 1200,
      node_timeout: 300
    });
  };
  
  // Handler for custom agent creation
  const handleAgentCreate = (agent: any) => {
    console.log('[SwarmChatV2] Creating custom agent:', agent);
    setCustomAgents(prev => [...prev, agent]);
    
    // Add the agent to dynamic agents
    setDynamicAgents(prev => [...prev, {
      id: agent.id,
      name: agent.name,
      description: agent.system_prompt,
      capabilities: agent.capabilities,
      status: 'idle',
      contributions: 0,
      created_by: agent.created_by
    }]);
  };

  const handleSend = async () => {
    if (!input.trim() || isExecuting) return;
    
    // Clear previous conversation items for new query
    setConversationItems([]);
    setUserMessages([]);
    setAgentMessages([]);
    // Don't clear dynamic agents - keep orchestrator and user created agents
    // Only clear workflow-specific agents from previous runs
    setDynamicAgents(prev => prev.filter(a => 
      a.created_by === 'user' || 
      (a.created_by === 'orchestrator' && !a.task_id)
    ));
    setTimelineEvents([]);
    
    // Reset processed events for new conversation
    processedEventsRef.current.clear();
    lastEventCountRef.current = 0;
    
    // Create new session for this conversation
    const sessionId = createSession(input.substring(0, 50)); // Use first 50 chars as title
    
    const userMsg: UserMessage = {
      id: `user-${Date.now()}`,
      content: input,
      timestamp: new Date()
    };
    
    // Add user message to conversation
    setConversationItems([{
      id: userMsg.id,
      type: 'user',
      content: input,
      timestamp: new Date()
    }]);
    
    // Add to session history
    if (sessionId) {
      addMessage(sessionId, {
        type: 'user',
        content: input,
        timestamp: new Date()
      });
    }
    
    setUserMessages([userMsg]);
    setInput('');
    
    // Reset swarm data
    setSwarmData({ 
      agents: [], 
      handoffs: [],
      sharedKnowledge: {}
    });
    
    console.log('[SwarmChatV2] Starting execution with task:', input);
    
    try {
      await execute({
        task: input,
        agents: [],  // Let the system decide agents dynamically
        max_handoffs: 20,  // Allow more handoffs for complex tasks
        max_iterations: 20,
        execution_timeout: 900,  // 15 minutes max
        node_timeout: 300  // 5 minutes per agent
      });
      console.log('[SwarmChatV2] Execution started successfully');
    } catch (error) {
      console.error('[SwarmChatV2] Execution failed:', error);
    }
  };
  
  const getAgentProfile = (agent: string): AgentProfile => {
    return AGENT_PROFILES[agent] || {
      name: agent,
      avatar: '🤖',
      color: '#6b7280'
    };
  };
  
  // Debug logging for agent messages
  console.log('[SwarmChatV2] Rendering agent messages:', agentMessages.length, agentMessages.map(m => ({ agent: m.agent, status: m.status, contentLength: m.content?.length || 0 })));

  return (
    <div className="swarm-chat-v2">
      {/* Header */}
      <div className="chat-header">
        <div className="header-left">
          <h1>🚀 Swarm AI Agents</h1>
          {isConnected && <span className="connection-badge">● Connected</span>}
          {currentSessionId && <span className="session-badge">Session Active</span>}
        </div>
        <div className="header-controls">
          <button 
            className={`view-toggle ${selectedView === 'conversation' ? 'active' : ''}`}
            onClick={() => setSelectedView('conversation')}
          >
            💬 Chat
          </button>
          <button 
            className={`view-toggle ${selectedView === 'team' ? 'active' : ''}`}
            onClick={() => setSelectedView('team')}
          >
            👥 Team
          </button>
          <button 
            className={`view-toggle ${selectedView === 'timeline' ? 'active' : ''}`}
            onClick={() => setSelectedView('timeline')}
          >
            <Clock size={16} /> Timeline
          </button>
          <button 
            className={`view-toggle ${selectedView === 'visualization' ? 'active' : ''}`}
            onClick={() => setSelectedView('visualization')}
          >
            <Brain size={16} /> Graph
          </button>
          <button 
            className={`view-toggle ${selectedView === 'orchestrator' ? 'active' : ''}`}
            onClick={() => setSelectedView('orchestrator')}
          >
            🎭 Orchestrator
          </button>
          <button 
            className={`view-toggle ${selectedView === 'advanced' ? 'active' : ''}`}
            onClick={() => setSelectedView('advanced')}
          >
            🚀 Advanced
          </button>
          <button 
            className={`view-toggle ${selectedView === 'enhanced' ? 'active' : ''}`}
            onClick={() => setSelectedView('enhanced')}
          >
            ✨ Enhanced
          </button>
        </div>
      </div>
      
      <div className="main-layout">
        {/* Chat Panel */}
        <div className="chat-panel">
          <div className="chat-messages">
            {userMessages.length === 0 && agentMessages.length === 0 && (
              <div className="welcome">
                <h2>Welcome to Swarm AI</h2>
                <p>Ask anything and watch specialized agents collaborate in real-time</p>
              </div>
            )}
            
            {/* User Messages */}
            {userMessages.map(msg => (
              <div key={msg.id} className="user-message">
                <div className="message-bubble">
                  <p>{msg.content}</p>
                  <span className="timestamp">
                    {msg.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
            
            {/* Show execution status when no agents yet */}
            {isExecuting && agentMessages.length === 0 && (
              <div className="system-message">
                <span className="thinking-indicator">
                  <span className="thinking-dot"></span>
                  <span className="thinking-dot"></span>
                  <span className="thinking-dot"></span>
                </span>
                Initializing agents...
              </div>
            )}
            
            {/* Agent Messages */}
            {agentMessages.map((msg, index) => {
              const profile = getAgentProfile(msg.agent);
              const isExpanded = expandedSections.has(msg.id);
              
              return (
                <div key={msg.id} className="agent-card">
                  {/* Agent Header */}
                  <div className="agent-header" style={{ borderColor: profile.color }}>
                    <div className="agent-info">
                      <span className="agent-avatar">{profile.avatar}</span>
                      <span className="agent-name" style={{ color: profile.color }}>
                        {profile.name}
                      </span>
                  {msg.status === 'thinking' && (
                    <span className="status-badge thinking">Thinking...</span>
                  )}
                  {msg.status === 'streaming' && (
                    <span className="status-badge streaming">Typing...</span>
                  )}
                  {msg.status === 'complete' && (
                    <span className="status-badge complete">Complete</span>
                  )}
                </div>
                
                {/* Action Buttons */}
                <div className="agent-actions">
                  {msg.thinking && msg.thinking.length > 0 && (
                    <button
                      className="action-btn"
                      onClick={() => toggleSection(`${msg.id}-thinking`)}
                      title="Toggle thinking"
                    >
                      <Brain size={16} />
                    </button>
                  )}
                  {msg.tools && msg.tools.length > 0 && (
                    <button
                      className="action-btn"
                      onClick={() => toggleSection(`${msg.id}-tools`)}
                      title="Toggle tools"
                    >
                      <Tool size={16} />
                    </button>
                  )}
                  {msg.codeBlocks && msg.codeBlocks.length > 0 && (
                    <button
                      className="action-btn"
                      onClick={() => toggleSection(`${msg.id}-code`)}
                      title="Toggle code"
                    >
                      <Code size={16} />
                    </button>
                  )}
                  <button
                    className="action-btn"
                    onClick={() => toggleSection(msg.id)}
                    title="Toggle details"
                  >
                    <Eye size={16} />
                  </button>
                </div>
              </div>
              
              {/* Agent Content - Always show main content, only collapse extra sections */}
              <div className="agent-content">
                {/* Thinking Section */}
                {msg.thinking && msg.thinking.length > 0 && 
                 expandedSections.has(`${msg.id}-thinking`) && (
                  <div className="section thinking-section">
                    <h4><Brain size={14} /> Thinking Process</h4>
                    {msg.thinking.map((thought, i) => (
                      <p key={i} className="thought">{thought}</p>
                    ))}
                  </div>
                )}
                
                {/* Tools Section */}
                {msg.tools && msg.tools.length > 0 && 
                 expandedSections.has(`${msg.id}-tools`) && (
                  <div className="section tools-section">
                    <h4><Tool size={14} /> Tools Used</h4>
                    <div className="tools-list">
                      {msg.tools.map((tool, i) => (
                        <span key={i} className={`tool-badge ${tool.status}`}>
                          {tool.name}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Main Content */}
                <div className="main-content">
                  {msg.status === 'thinking' && (
                    <p className="thinking-text">
                      <span className="thinking-indicator">
                        <span className="thinking-dot"></span>
                        <span className="thinking-dot"></span>
                        <span className="thinking-dot"></span>
                      </span>
                      Thinking...
                    </p>
                  )}
                  {msg.status === 'streaming' && (
                    <p className="streaming-text">
                      {msg.streamingContent || 'Starting response...'}
                      <span className="cursor">▊</span>
                    </p>
                  )}
                  {msg.status === 'working' && (
                    <p>Working on the task...</p>
                  )}
                  {msg.status === 'complete' && (
                    <p>{msg.content || msg.streamingContent || 'Task completed.'}</p>
                  )}
                </div>
                
                {/* Artifacts Viewer for Code */}
                {msg.codeBlocks && msg.codeBlocks.length > 0 && (
                  <div className="artifacts-section">
                    <ArtifactsViewer 
                      artifacts={msg.codeBlocks}
                      title="Generated Code"
                      agentName={profile.name}
                    />
                  </div>
                )}
              </div>
              
              {/* Agent transition indicator */}
              {index < agentMessages.length - 1 && msg.status === 'complete' && (
                <div className="agent-transition">
                  <span>→ Handing off to next agent</span>
                </div>
              )}
            </div>
          );
            })}
            
            <div ref={messagesEndRef} />
          </div>
          
          {/* Input */}
          <div className="chat-input">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={isExecuting ? "Agents working..." : "Ask anything..."}
              disabled={isExecuting}
            />
            <button onClick={handleSend} disabled={!input.trim() || isExecuting}>
              <Send />
            </button>
          </div>
        </div>
        
        {/* Center Panel - Different Views */}
        <div className="center-panel">
          {selectedView === 'conversation' && (
            <SwarmConversation
              items={conversationItems}
              isStreaming={isExecuting}
            />
          )}
          {selectedView === 'team' && (
            <AgentTeamPanel
              agents={dynamicAgents}
              currentAgent={swarmData.currentAgent}
              sharedKnowledge={swarmData.sharedKnowledge}
            />
          )}
          {selectedView === 'timeline' && (
            <SimpleAgentTimeline
              events={timelineEvents}
              currentAgent={swarmData.currentAgent}
            />
          )}
          {selectedView === 'visualization' && (
            <SwarmVisualization
              agents={swarmData.agents}
              handoffs={swarmData.handoffs}
              currentAgent={swarmData.currentAgent}
              sharedMemory={swarmData.sharedMemory}
            />
          )}
          {selectedView === 'orchestrator' && (
            <OrchestratorPanel
              onWorkflowStart={handleWorkflowStart}
              onAgentCreate={handleAgentCreate}
              currentWorkflow={currentWorkflow}
              availableAgents={[...dynamicAgents, ...customAgents]}
            />
          )}
          {selectedView === 'advanced' && (
            <AdvancedOrchestratorPanel
              onWorkflowStart={handleAdvancedWorkflowStart}
              currentWorkflow={currentWorkflow}
            />
          )}
          {selectedView === 'enhanced' && (
            <EnhancedOrchestratorPanel
              onWorkflowStart={handleAdvancedWorkflowStart}
              currentWorkflow={currentWorkflow}
            />
          )}
        </div>
        
        {/* Right Panel - Artifacts */}
        <div className="artifacts-panel">
          <div className="panel-header">
            <h3>📦 Generated Code & Artifacts</h3>
          </div>
          <div className="artifacts-content">
            {agentMessages
              .filter(msg => msg.codeBlocks && msg.codeBlocks.length > 0)
              .map(msg => (
                <div key={msg.id} className="artifact-section">
                  <h4>{getAgentProfile(msg.agent).name}</h4>
                  {msg.codeBlocks?.map((block, idx) => (
                    <div key={idx} className="code-block-wrapper">
                      <div className="code-header">
                        <span className="file-name">{block.name}</span>
                        <span className="language">{block.language}</span>
                      </div>
                      <pre className="code-content">
                        <code>{block.content}</code>
                      </pre>
                    </div>
                  ))}
                </div>
              ))}
            {agentMessages.every(m => !m.codeBlocks || m.codeBlocks.length === 0) && (
              <div className="no-artifacts">
                <p>No code generated yet</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SwarmChatV2;