import React, { useState, useRef, useEffect } from 'react';
import { useSwarmExecution } from '../hooks/useSwarmExecution';
import { SwarmEvent } from '../types/swarm';
import './SwarmChat.css';

// Icon components as simple SVGs since lucide-react has issues
const Send = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);

const Sparkles = ({ size = 24, className = '' }: { size?: number; className?: string }) => (
  <svg width={size} height={size} className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 2L15.09 8.36L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.36L12 2Z"></path>
  </svg>
);

const User = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
    <circle cx="12" cy="7" r="4"></circle>
  </svg>
);

const ArrowRight = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="5" y1="12" x2="19" y2="12"></line>
    <polyline points="12 5 19 12 12 19"></polyline>
  </svg>
);

const Code = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="16 18 22 12 16 6"></polyline>
    <polyline points="8 6 2 12 8 18"></polyline>
  </svg>
);

const Bot = ({ size = 24 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="11" width="18" height="10" rx="2" ry="2"></rect>
    <circle cx="12" cy="5" r="2"></circle>
    <path d="M12 7v4"></path>
  </svg>
);

const CheckCircle = ({ size = 24, className = '' }: { size?: number; className?: string }) => (
  <svg width={size} height={size} className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
    <polyline points="22 4 12 14.01 9 11.01"></polyline>
  </svg>
);

interface Message {
  id: string;
  type: 'user' | 'agent' | 'handoff' | 'system';
  agent?: string;
  content: string;
  timestamp: Date;
  status?: 'typing' | 'thinking' | 'complete';
  artifacts?: any[];
}

interface AgentInfo {
  name: string;
  avatar: string;
  color: string;
  status: 'idle' | 'working' | 'thinking' | 'typing';
}

const AGENT_PROFILES: Record<string, AgentInfo> = {
  researcher: {
    name: 'Researcher',
    avatar: '🔬',
    color: '#6366f1',
    status: 'idle'
  },
  architect: {
    name: 'Architect',
    avatar: '🏗️',
    color: '#8b5cf6',
    status: 'idle'
  },
  developer: {
    name: 'Developer',
    avatar: '💻',
    color: '#10b981',
    status: 'idle'
  },
  reviewer: {
    name: 'Reviewer',
    avatar: '✅',
    color: '#f59e0b',
    status: 'idle'
  },
  tester: {
    name: 'Tester',
    avatar: '🧪',
    color: '#ef4444',
    status: 'idle'
  },
  data_scientist: {
    name: 'Data Scientist',
    avatar: '📊',
    color: '#06b6d4',
    status: 'idle'
  },
  devops: {
    name: 'DevOps',
    avatar: '🚀',
    color: '#84cc16',
    status: 'idle'
  }
};

const SwarmChat: React.FC = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeAgents, setActiveAgents] = useState<Set<string>>(new Set());
  const [agentStatuses, setAgentStatuses] = useState<Record<string, string>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { execute, events, isExecuting, result, isConnected } = useSwarmExecution();

  // Track processed events to avoid duplicates
  const processedEventsRef = useRef<Set<string>>(new Set());
  
  // Process events into messages
  useEffect(() => {
    events.forEach(event => {
      // Create unique event key
      const eventKey = `${event.type}-${event.timestamp}-${event.agent || 'system'}`;
      
      // Only process if not already processed
      if (!processedEventsRef.current.has(eventKey)) {
        processedEventsRef.current.add(eventKey);
        processEventToMessage(event);
      }
    });
  }, [events]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const processEventToMessage = (event: SwarmEvent) => {
    const timestamp = new Date(event.timestamp);

    switch (event.type) {
      case 'execution_started':
        setMessages(prev => [...prev, {
          id: `start-${Date.now()}`,
          type: 'system',
          content: '🎯 Swarm initialized. Agents are preparing to collaborate...',
          timestamp
        }]);
        break;

      case 'agent_started':
        const agent = event.agent || 'unknown';
        setActiveAgents(prev => new Set(Array.from(prev).concat(agent)));
        setAgentStatuses(prev => ({ ...prev, [agent]: 'thinking' }));
        
        // Check if agent message already exists
        setMessages(prev => {
          const existingAgentMsg = prev.find(
            m => m.agent === agent && m.type === 'agent' && m.status !== 'complete'
          );
          
          if (!existingAgentMsg) {
            return [...prev, {
              id: `agent-${agent}-${Date.now()}`,
              type: 'agent',
              agent,
              content: '',
              timestamp,
              status: 'thinking'
            }];
          }
          return prev;
        });
        break;

      case 'text_generation':
        if (event.agent && event.data) {
          const agentName = event.agent;
          const accumulatedText = event.data.accumulated || '';
          
          setAgentStatuses(prev => ({ ...prev, [agentName]: 'typing' }));
          
          setMessages(prev => {
            // Find the most recent message for this agent
            const agentMessageIndex = prev.findIndex(
              m => m.agent === agentName && m.type === 'agent' && m.status !== 'complete'
            );
            
            if (agentMessageIndex !== -1) {
              const updated = [...prev];
              updated[agentMessageIndex] = {
                ...updated[agentMessageIndex],
                content: accumulatedText,
                status: 'typing'
              };
              return updated;
            } else {
              // Create new agent message if doesn't exist
              return [...prev, {
                id: `agent-${agentName}-${Date.now()}`,
                type: 'agent',
                agent: agentName,
                content: accumulatedText,
                timestamp,
                status: 'typing'
              }];
            }
          });
        }
        break;

      case 'agent_completed':
        if (event.agent) {
          const completedAgent = event.agent;
          setAgentStatuses(prev => ({ ...prev, [completedAgent]: 'complete' }));
          
          setMessages(prev => {
            const agentMessageIndex = prev.findIndex(
              m => m.agent === completedAgent && m.type === 'agent' && m.status !== 'complete'
            );
            
            if (agentMessageIndex !== -1) {
              const updated = [...prev];
              updated[agentMessageIndex] = {
                ...updated[agentMessageIndex],
                status: 'complete'
              };
              return updated;
            }
            return prev;
          });
        }
        break;

      case 'handoff':
        const fromAgent = event.data?.from || 'Agent';
        const toAgent = event.data?.to || 'Next Agent';
        
        setMessages(prev => [...prev, {
          id: `handoff-${Date.now()}`,
          type: 'handoff',
          content: `${fromAgent} → ${toAgent}`,
          timestamp
        }]);
        break;

      case 'execution_completed':
        setMessages(prev => [...prev, {
          id: `complete-${Date.now()}`,
          type: 'system',
          content: '✨ Task completed successfully! All agents have finished their work.',
          timestamp
        }]);
        setActiveAgents(new Set());
        break;

      case 'execution_failed':
        setMessages(prev => [...prev, {
          id: `error-${Date.now()}`,
          type: 'system',
          content: `❌ Error: ${event.data?.error || 'Unknown error occurred'}`,
          timestamp
        }]);
        setActiveAgents(new Set());
        break;
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isExecuting) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Execute swarm with required parameters
    await execute({ 
      task: input,
      agents: [], // Empty array to use auto-selection
      max_handoffs: 20,
      max_iterations: 20,
      execution_timeout: 900,
      node_timeout: 300
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const getAgentProfile = (agentName: string): AgentInfo => {
    return AGENT_PROFILES[agentName] || {
      name: agentName,
      avatar: '🤖',
      color: '#6b7280',
      status: 'idle'
    };
  };

  const renderMessage = (message: Message) => {
    if (message.type === 'user') {
      return (
        <div className="message-wrapper user-message-wrapper">
          <div className="message user-message">
            <div className="message-avatar">
              <User size={20} />
            </div>
            <div className="message-content">
              <div className="message-header">
                <span className="message-sender">You</span>
                <span className="message-time">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <div className="message-text">{message.content}</div>
            </div>
          </div>
        </div>
      );
    }

    if (message.type === 'agent' && message.agent) {
      const profile = getAgentProfile(message.agent);
      const isTyping = message.status === 'typing';
      const isThinking = message.status === 'thinking';

      return (
        <div className="message-wrapper agent-message-wrapper">
          <div className="message agent-message">
            <div 
              className="message-avatar agent-avatar"
              style={{ backgroundColor: profile.color }}
            >
              <span className="agent-emoji">{profile.avatar}</span>
            </div>
            <div className="message-content">
              <div className="message-header">
                <span className="message-sender" style={{ color: profile.color }}>
                  {profile.name}
                </span>
                {message.status === 'complete' && (
                  <CheckCircle size={16} className="status-icon complete" />
                )}
                <span className="message-time">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <div className="message-text">
                {isThinking && !message.content && (
                  <div className="thinking-indicator">
                    <span className="thinking-dot"></span>
                    <span className="thinking-dot"></span>
                    <span className="thinking-dot"></span>
                  </div>
                )}
                {message.content && (
                  <>
                    {message.content}
                    {isTyping && <span className="typing-cursor">▊</span>}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (message.type === 'handoff') {
      return (
        <div className="handoff-message">
          <ArrowRight size={16} />
          <span>{message.content}</span>
        </div>
      );
    }

    if (message.type === 'system') {
      return (
        <div className="system-message">
          <span>{message.content}</span>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="swarm-chat-container">
      {/* Header */}
      <div className="swarm-chat-header">
        <div className="header-left">
          <Sparkles className="header-icon" />
          <h1>Swarm AI Agents</h1>
        </div>
        <div className="header-right">
          {isConnected && (
            <div className="connection-status connected">
              <span className="status-dot"></span>
              Connected
            </div>
          )}
          {activeAgents.size > 0 && (
            <div className="active-agents">
              {Array.from(activeAgents).map(agent => {
                const profile = getAgentProfile(agent);
                return (
                  <div
                    key={agent}
                    className="active-agent-badge"
                    style={{ backgroundColor: profile.color }}
                    title={`${profile.name} is ${agentStatuses[agent] || 'working'}`}
                  >
                    <span>{profile.avatar}</span>
                    {agentStatuses[agent] === 'typing' && (
                      <span className="agent-typing-indicator"></span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <div className="swarm-chat-messages">
        {messages.length === 0 && (
          <div className="welcome-message">
            <Sparkles size={48} className="welcome-icon" />
            <h2>Welcome to Swarm AI</h2>
            <p>Ask me anything and watch as specialized AI agents collaborate to solve your request.</p>
            <div className="example-prompts">
              <button onClick={() => setInput("Build a REST API for a todo app")}>
                <Code size={16} />
                Build a REST API
              </button>
              <button onClick={() => setInput("Analyze this data and create visualizations")}>
                <Bot size={16} />
                Data Analysis
              </button>
              <button onClick={() => setInput("Design a microservices architecture")}>
                <Sparkles size={16} />
                System Architecture
              </button>
            </div>
          </div>
        )}
        
        {messages.map(message => (
          <React.Fragment key={message.id}>
            {renderMessage(message)}
          </React.Fragment>
        ))}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="swarm-chat-input">
        <div className="input-container">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isExecuting ? "Agents are working..." : "Ask anything..."}
            disabled={isExecuting}
            rows={1}
            className="chat-textarea"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isExecuting}
            className="send-button"
          >
            {isExecuting ? (
              <div className="sending-spinner"></div>
            ) : (
              <Send size={20} />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SwarmChat;