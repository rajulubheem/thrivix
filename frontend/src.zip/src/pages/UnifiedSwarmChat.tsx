import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useSwarmExecution } from '../hooks/useSwarmExecution';
import UnifiedAgentPanel from '../components/UnifiedAgentPanel';
import NewArtifactsPanel from '../components/ArtifactsPanel';
import ImprovedTimeline from '../components/ImprovedTimeline';
import { EnhancedOrchestratorPanel } from '../components/EnhancedOrchestratorPanel';
import EnhancedMessage from '../components/EnhancedMessage';
import { Artifact, createArtifact } from '../types/artifacts'; // Import unified types
import './UnifiedSwarmChat.css';

// Types that match your existing codebase
interface Message {
  id: string;
  type: 'user' | 'agent' | 'system' | 'handoff';
  agent?: string;
  content: string;
  timestamp: Date;
  status?: 'thinking' | 'streaming' | 'complete' | 'error';
  artifacts?: Artifact[]; // Changed from ArtifactRef[] to Artifact[]
  metadata?: any;
}

interface Agent {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
  status: 'idle' | 'thinking' | 'working' | 'streaming' | 'complete' | 'error';
  contributions: number;
  lastActivity?: string;
  currentTask?: string;
  tokensUsed?: number;
  toolsUsed?: string[];
}

interface AgentActivity {
  agentName: string;
  action: string;
  timestamp: Date;
  type: 'handoff' | 'tool' | 'message' | 'complete' | 'error';
  details?: any;
}

// Using your original ArtifactRef interface
interface ArtifactRef {
  id: string;
  name: string;
  type: 'code' | 'document' | 'data' | 'image' | 'test_result' | 'html';
  content?: string;
  path?: string;
  size?: number;
  metadata?: {
    language?: string;
    agent?: string;
    timestamp?: string;
    lines?: number;
    [key: string]: any;
  };
}

// Extended types for orchestrator
interface OrchestratorAgent {
  id: string;
  name: string;
  role: string;
  tools: string[];
  model: string;
  temperature: number;
  system_prompt: string;
  color: string;
}

interface OrchestratorState {
  taskInput: string;
  agents: OrchestratorAgent[];
  selectedTools: { [agentId: string]: string[] };
  expandedAgent: string | null;
  showToolLibrary: boolean;
  selectedCategory: string;
}

// View modes
type ViewMode = 'chat' | 'timeline' | 'orchestrator';

const UnifiedSwarmChat: React.FC = () => {
  // Core state
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [activities, setActivities] = useState<AgentActivity[]>([]);
  const [sharedContext, setSharedContext] = useState<Record<string, any>>({});
  const [currentAgent, setCurrentAgent] = useState<string | undefined>();
  const [viewMode, setViewMode] = useState<ViewMode>('chat');
  const [showArtifacts, setShowArtifacts] = useState(true);
  const [allArtifacts, setAllArtifacts] = useState<Artifact[]>([]); // Changed to Artifact[]

  // FIXED: Persistent orchestrator state
  const [orchestratorState, setOrchestratorState] = useState<OrchestratorState>({
    taskInput: '',
    agents: [],
    selectedTools: {},
    expandedAgent: null,
    showToolLibrary: false,
    selectedCategory: 'all'
  });

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const processedEventsRef = useRef<Set<string>>(new Set());
  const streamBufferRef = useRef<Map<string, string>>(new Map());

  // Swarm execution hook
  const { execute, events, isExecuting, isConnected, result, error } = useSwarmExecution();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Reset execution state when starting new execution (but preserve orchestrator state)
  const resetExecutionState = useCallback(() => {
    setMessages([]);
    setAgents([]);
    setActivities([]);
    setSharedContext({});
    setCurrentAgent(undefined);
    setAllArtifacts([]);
    processedEventsRef.current.clear();
    streamBufferRef.current.clear();
  }, []);

  // Handle artifact management
  const handleArtifactSelect = useCallback((artifact: Artifact) => {
    console.log('Selected artifact:', artifact);
  }, []);

  const handleArtifactDelete = useCallback((artifactId: string) => {
    setAllArtifacts(prev => prev.filter(a => a.id !== artifactId));

    // Also remove from messages
    setMessages(prev => prev.map(msg => ({
      ...msg,
      artifacts: msg.artifacts?.filter(a => a.id !== artifactId) || []
    })));
  }, []);

  // Handle artifact creation from message component
  const handleArtifactCreate = useCallback((artifact: any, messageId?: string) => {
    const newArtifact: Artifact = createArtifact({
      name: artifact.title || artifact.filename || 'Untitled',
      type: artifact.type === 'html' ? 'html' : artifact.type || 'code',
      content: artifact.content || '',
      language: artifact.language,
      agent: currentAgent,
      metadata: artifact.metadata
    });

    setAllArtifacts(prev => [...prev, newArtifact]);

    // Also add to the specific message if messageId provided
    if (messageId) {
      setMessages(prev => prev.map(msg =>
          msg.id === messageId
              ? { ...msg, artifacts: [...(msg.artifacts || []), newArtifact] }
              : msg
      ));
    }
  }, [currentAgent]);

  // FIXED: Handle orchestrator state updates
  const handleOrchestratorStateUpdate = useCallback((updates: Partial<OrchestratorState>) => {
    setOrchestratorState(prev => ({ ...prev, ...updates }));
  }, []);

  // FIXED: Auto-detect and extract artifacts from agent messages
  const extractArtifactsFromContent = useCallback((content: string, agentName: string): Artifact[] => {
    const artifacts: Artifact[] = [];

    // Extract code blocks that could be artifacts
    const codeBlockRegex = /```(\w+)?\n?([\s\S]*?)```/g;
    const fileRegex = /#\s*filename:\s*([^\n]+)\n([\s\S]*?)(?=\n#|\n```|$)/g;

    let match;
    let artifactIndex = 0;

    // Extract files with filenames
    while ((match = fileRegex.exec(content)) !== null) {
      const filename = match[1].trim();
      const fileContent = match[2].trim();
      const extension = filename.split('.').pop()?.toLowerCase() || 'txt';

      let type: Artifact['type'] = 'document';
      let language = extension;

      if (['html', 'htm'].includes(extension)) type = 'html';
      else if (['js', 'ts', 'py', 'css', 'sql', 'json', 'xml', 'yaml'].includes(extension)) type = 'code';
      else if (['csv', 'json', 'xml'].includes(extension)) type = 'data';

      artifacts.push(createArtifact({
        name: filename,
        type,
        content: fileContent,
        language,
        agent: agentName
      }));
      artifactIndex++;
    }

    // Extract large code blocks (>100 chars) without filenames
    while ((match = codeBlockRegex.exec(content)) !== null) {
      const language = match[1] || 'text';
      const code = match[2].trim();

      // Only create artifacts for substantial code blocks
      if (code.length > 100) {
        const type: Artifact['type'] = language === 'html' ? 'html' : 'code';

        artifacts.push(createArtifact({
          name: `${language}_code_${artifactIndex}.${language}`,
          type,
          content: code,
          language,
          agent: agentName
        }));
        artifactIndex++;
      }
    }

    return artifacts;
  }, []);

  // Process events into UI state
  useEffect(() => {
    events.forEach(event => {
      const eventKey = `${event.type}-${event.timestamp}-${event.agent || 'system'}`;

      if (processedEventsRef.current.has(eventKey)) return;
      processedEventsRef.current.add(eventKey);

      switch (event.type) {
        case 'agent_started':
          if (event.agent) {
            const agentName = event.agent;

            // Update or add agent
            setAgents(prev => {
              const existing = prev.find(a => a.name === agentName);
              if (existing) {
                return prev.map(a =>
                    a.name === agentName
                        ? { ...a, status: 'thinking', currentTask: 'Starting task...' }
                        : a
                );
              } else {
                return [...prev, {
                  id: `agent-${agentName}-${Date.now()}`,
                  name: agentName,
                  description: event.data?.description || `${agentName} specialist`,
                  capabilities: event.data?.capabilities || [],
                  status: 'thinking',
                  contributions: 0,
                  currentTask: 'Starting task...',
                  toolsUsed: []
                }];
              }
            });

            setCurrentAgent(agentName);

            // Add activity
            setActivities(prev => [...prev, {
              agentName,
              action: 'Started working',
              timestamp: new Date(),
              type: 'message'
            }]);

            // Add message if not exists
            setMessages(prev => {
              const hasMessage = prev.some(m =>
                  m.agent === agentName && m.status !== 'complete'
              );

              if (!hasMessage) {
                return [...prev, {
                  id: `msg-${agentName}-${Date.now()}`,
                  type: 'agent',
                  agent: agentName,
                  content: '',
                  timestamp: new Date(),
                  status: 'thinking'
                }];
              }
              return prev;
            });
          }
          break;

        case 'text_generation':
          if (event.agent && event.data) {
            const agentName = event.agent;
            const content = event.data.accumulated || '';

            streamBufferRef.current.set(agentName, content);

            // Update agent status
            setAgents(prev => prev.map(a =>
                a.name === agentName
                    ? { ...a, status: 'streaming', currentTask: 'Generating response...' }
                    : a
            ));

            // Update message
            setMessages(prev => {
              const msgIndex = prev.findIndex(m =>
                  m.agent === agentName && m.status !== 'complete'
              );

              if (msgIndex !== -1) {
                const updated = [...prev];
                updated[msgIndex] = {
                  ...updated[msgIndex],
                  content,
                  status: 'streaming'
                };
                return updated;
              }
              return prev;
            });
          }
          break;

        case 'tool_use':
          if (event.agent && event.data?.tool) {
            const agentName = event.agent;
            const toolName = event.data.tool;

            // Update agent tools
            setAgents(prev => prev.map(a => {
              if (a.name === agentName) {
                const tools = a.toolsUsed || [];
                if (!tools.includes(toolName)) {
                  tools.push(toolName);
                }
                return { ...a, toolsUsed: tools, currentTask: `Using ${toolName}...` };
              }
              return a;
            }));

            // Add activity
            setActivities(prev => [...prev, {
              agentName,
              action: `Used tool: ${toolName}`,
              timestamp: new Date(),
              type: 'tool'
            }]);
          }
          break;

        case 'handoff':
          if (event.data) {
            const { from_agent, to_agent, reason, shared_knowledge } = event.data;

            // Add handoff message
            setMessages(prev => [...prev, {
              id: `handoff-${Date.now()}`,
              type: 'handoff',
              content: `${from_agent} → ${to_agent}${reason ? `: ${reason}` : ''}`,
              timestamp: new Date()
            }]);

            // Update agents
            setAgents(prev => prev.map(a => {
              if (a.name === from_agent) {
                return { ...a, status: 'complete', currentTask: 'Completed' };
              }
              if (a.name === to_agent) {
                return { ...a, status: 'thinking', currentTask: 'Taking over...' };
              }
              return a;
            }));

            // Update shared context
            if (shared_knowledge) {
              setSharedContext(prev => ({
                ...prev,
                [from_agent]: shared_knowledge
              }));
            }

            // Add activity
            setActivities(prev => [...prev, {
              agentName: from_agent,
              action: `Handed off to ${to_agent}`,
              timestamp: new Date(),
              type: 'handoff',
              details: { to: to_agent, reason }
            }]);

            setCurrentAgent(to_agent);
          }
          break;

        case 'agent_completed':
          if (event.agent) {
            const agentName = event.agent;

            // Clear stream buffer
            const finalContent = streamBufferRef.current.get(agentName) || '';
            streamBufferRef.current.delete(agentName);

            // Extract artifacts from final content
            const extractedArtifacts = extractArtifactsFromContent(finalContent, agentName);

            // Update agent
            setAgents(prev => prev.map(a =>
                a.name === agentName
                    ? {
                      ...a,
                      status: 'complete',
                      contributions: a.contributions + 1,
                      currentTask: 'Task completed'
                    }
                    : a
            ));

            // Update message with artifacts
            setMessages(prev => {
              const msgIndex = prev.findIndex(m =>
                  m.agent === agentName && m.status !== 'complete'
              );

              if (msgIndex !== -1) {
                const updated = [...prev];
                updated[msgIndex] = {
                  ...updated[msgIndex],
                  status: 'complete',
                  artifacts: extractedArtifacts
                };
                return updated;
              }
              return prev;
            });

            // Add artifacts to global collection
            if (extractedArtifacts.length > 0) {
              setAllArtifacts(prev => [...prev, ...extractedArtifacts]);
            }

            // Add activity
            setActivities(prev => [...prev, {
              agentName,
              action: 'Completed task',
              timestamp: new Date(),
              type: 'complete'
            }]);
          }
          break;
      }
    });
  }, [events, extractArtifactsFromContent]);

  // Handle sending message
  const handleSend = async () => {
    if (!input.trim() || isExecuting) return;

    resetExecutionState();

    // Add user message
    setMessages([{
      id: `user-${Date.now()}`,
      type: 'user',
      content: input,
      timestamp: new Date()
    }]);

    const task = input;
    setInput('');

    // Execute
    await execute({
      task,
      agents: [],
      max_handoffs: 20,
      max_iterations: 20,
      execution_timeout: 900,
      node_timeout: 300
    });
  };

  // FIXED: Handle workflow from orchestrator with persistent state update
  const handleWorkflowStart = async (workflow: any) => {
    resetExecutionState();

    // Add system message
    setMessages([{
      id: `system-${Date.now()}`,
      type: 'system',
      content: `🚀 Starting workflow: ${workflow.name || workflow.description}`,
      timestamp: new Date()
    }]);

    // Execute workflow
    const workflowTask = workflow.tasks
        .map((t: any, i: number) => `${i + 1}. ${t.agent_type}: ${t.description}`)
        .join('\n');

    await execute({
      task: workflowTask,
      agents: workflow.agents || [],
      max_handoffs: 30,
      max_iterations: 30,
      execution_timeout: 1200,
      node_timeout: 300
    });

    // Switch to chat view to see execution
    setViewMode('chat');
  };

  // Get agent profile
  const getAgentProfile = (name: string) => {
    const profiles: Record<string, { emoji: string; color: string }> = {
      researcher: { emoji: '🔬', color: '#10b981' },
      architect: { emoji: '🏗️', color: '#8b5cf6' },
      developer: { emoji: '💻', color: '#06b6d4' },
      reviewer: { emoji: '✅', color: '#f59e0b' },
      default: { emoji: '🤖', color: '#6b7280' }
    };
    return profiles[name] || profiles.default;
  };

  return (
      <div className="unified-swarm-chat">
        {/* Header */}
        <div className="chat-header">
          <div className="header-left">
            <div className="logo">
              <span className="logo-icon">🚀</span>
              <h1>Swarm AI</h1>
            </div>
            <div className="status-indicators">
              {isConnected && <span className="status-badge connected">● Connected</span>}
              {isExecuting && <span className="status-badge executing">⚡ Executing</span>}
              {agents.filter(a => a.status === 'working' || a.status === 'streaming').length > 0 && (
                  <span className="status-badge active">
                {agents.filter(a => a.status === 'working' || a.status === 'streaming').length} Active
              </span>
              )}
            </div>
          </div>

          <div className="header-right">
            <div className="view-switcher">
              <button
                  className={`view-btn ${viewMode === 'chat' ? 'active' : ''}`}
                  onClick={() => setViewMode('chat')}
              >
                💬 Chat
              </button>
              <button
                  className={`view-btn ${viewMode === 'timeline' ? 'active' : ''}`}
                  onClick={() => setViewMode('timeline')}
              >
                📊 Timeline
              </button>
              <button
                  className={`view-btn ${viewMode === 'orchestrator' ? 'active' : ''}`}
                  onClick={() => setViewMode('orchestrator')}
              >
                🎯 Orchestrator
              </button>
            </div>

            <button
                className={`artifacts-toggle ${showArtifacts ? 'active' : ''}`}
                onClick={() => setShowArtifacts(!showArtifacts)}
            >
              📦 Artifacts {allArtifacts.length > 0 && `(${allArtifacts.length})`}
            </button>
          </div>
        </div>

        <div className="chat-layout">
          {/* Left Panel - Agent Team */}
          <div className="left-panel">
            <UnifiedAgentPanel
                agents={agents}
                currentAgent={currentAgent}
                activities={activities}
                sharedContext={sharedContext}
                isExecuting={isExecuting}
            />
          </div>

          {/* Center Panel - Main Content */}
          <div className="center-panel">
            {viewMode === 'chat' && (
                <div className="chat-view" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <div className="messages-container">
                    {messages.length === 0 && (
                        <div className="welcome">
                          <h2>Welcome to Swarm AI</h2>
                          <p>Ask anything and watch specialized agents collaborate</p>
                          <div className="quick-actions">
                            <button onClick={() => setInput("Build a REST API for a todo app")}>
                              Build REST API
                            </button>
                            <button onClick={() => setInput("Analyze customer data and create insights")}>
                              Data Analysis
                            </button>
                            <button onClick={() => setInput("Design a microservices architecture")}>
                              System Design
                            </button>
                          </div>
                        </div>
                    )}

                    {messages.map(msg => {
                      if (msg.type === 'user') {
                        return (
                            <div key={msg.id} className="message user-message">
                              <div className="message-content">
                                <p>{msg.content}</p>
                                <span className="timestamp">{msg.timestamp.toLocaleTimeString()}</span>
                              </div>
                            </div>
                        );
                      }

                      if (msg.type === 'agent' && msg.agent) {
                        const profile = getAgentProfile(msg.agent);
                        return (
                            <div key={msg.id} className="message agent-message">
                              <div className="agent-avatar" style={{ backgroundColor: profile.color }}>
                                {profile.emoji}
                              </div>
                              <div className="message-wrapper">
                                <div className="message-header">
                            <span className="agent-name" style={{ color: profile.color }}>
                              {msg.agent}
                            </span>
                                  {msg.status === 'thinking' && <span className="status">Thinking...</span>}
                                  {msg.status === 'streaming' && <span className="status">Typing...</span>}
                                  {msg.status === 'complete' && <span className="status">✓</span>}
                                </div>
                                <div className="message-content">
                                  {msg.status === 'thinking' && !msg.content && (
                                      <div className="thinking-dots">
                                        <span></span><span></span><span></span>
                                      </div>
                                  )}
                                  {msg.content && (
                                      <EnhancedMessage
                                          content={msg.content}
                                          agent={msg.agent}
                                          status={msg.status}
                                          timestamp={msg.timestamp}
                                          onArtifactCreate={(artifact) => handleArtifactCreate(artifact, msg.id)}
                                          artifacts={msg.artifacts || []} // FIXED: No more mapping needed
                                      />
                                  )}
                                  {msg.status === 'streaming' && <span className="cursor">▊</span>}
                                </div>
                              </div>
                            </div>
                        );
                      }

                      if (msg.type === 'handoff') {
                        return (
                            <div key={msg.id} className="handoff-message">
                              <span>{msg.content}</span>
                            </div>
                        );
                      }

                      if (msg.type === 'system') {
                        return (
                            <div key={msg.id} className="system-message">
                              <span>{msg.content}</span>
                            </div>
                        );
                      }

                      return null;
                    })}

                    <div ref={messagesEndRef} />
                  </div>

                  <div className="chat-input-container">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder={isExecuting ? "Agents working..." : "Ask anything..."}
                        disabled={isExecuting}
                        className="chat-input"
                    />
                    <button
                        onClick={handleSend}
                        disabled={!input.trim() || isExecuting}
                        className="send-button"
                    >
                      {isExecuting ? '⏳' : '➤'}
                    </button>
                  </div>
                </div>
            )}

            {viewMode === 'timeline' && (
                <div className="timeline-view-container" style={{ height: '100%', overflow: 'hidden' }}>
                  <ImprovedTimeline
                      events={activities.map(a => ({
                        agent: a.agentName,
                        action: a.action,
                        status: a.type === 'complete' ? 'complete' as const :
                            a.type === 'error' ? 'error' as const :
                                'running' as const,
                        timestamp: a.timestamp,
                        details: a.details
                      }))}
                      currentAgent={currentAgent}
                      autoScroll={true}
                  />
                </div>
            )}

            {viewMode === 'orchestrator' && (
                <div className="orchestrator-view-container" style={{ height: '100%', overflow: 'auto' }}>
                  <EnhancedOrchestratorPanel
                      onWorkflowStart={handleWorkflowStart}
                      currentWorkflow={null}
                      // FIXED: Pass persistent state and update handler
                      persistentState={orchestratorState}
                      onStateUpdate={handleOrchestratorStateUpdate}
                  />
                </div>
            )}
          </div>

          {/* Right Panel - New Artifacts Panel */}
          {showArtifacts && (
              <div className="right-panel">
                <NewArtifactsPanel
                    artifacts={allArtifacts}
                    onArtifactSelect={handleArtifactSelect}
                    onArtifactDelete={handleArtifactDelete}
                    title="Generated Artifacts"
                    showActions={true}
                />
              </div>
          )}
        </div>
      </div>
  );
};

export default UnifiedSwarmChat;